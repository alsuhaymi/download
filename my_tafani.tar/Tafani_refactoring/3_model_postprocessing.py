import logging
import time

import utils.mle_utils as mle_utils
import utils.sql_code as sql_code
from settings import settings
from utils import send_mail
from utils.logging_setup import setup_logger


def run():
    start = time.monotonic()
    logging.info("Model postprocessing started")
    logging.info("Creating Hive connection for execute after model function")
    # hive_conn = mle_utils.hive_connection()
    spark_conn = mle_utils.spark_connection()
    logging.info("Creating TD connection for execute after model function")
    td_conn = mle_utils.create_teradata_connection()
    # sql_code.excute_after_model(td_conn, hive_conn)
    sql_code.excute_after_model(td_conn, spark_conn)
    end = time.monotonic()
    logging.info(f"Model postprocessing ended successfully in {end-start:.2f} seconds")
    return True, "Everything is ok !!"


if __name__ == "__main__":
    # setup logger
    log_file_path, log_file_database_path = setup_logger(
        "INFO", settings.log_dir, settings.log_file_name
    )
    status, message = run()
    # Mail Notification
    if settings.send_mail:
        send_mail(
            smtp_host=settings.smtp_host,
            smtp_port=settings.smtp_port,
            smtp_from=settings.smtp_from,
            smtp_to=settings.smtp_to,
            smtp_cc=settings.smtp_cc,
            content=message + "\nLog in attached file",
            subject=f"""Tafani - logs for model postprocessing job""",
            attachment=log_file_path,
        )
