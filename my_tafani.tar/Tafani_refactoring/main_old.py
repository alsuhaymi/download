import os
import time

os.system("pwd")
os.chdir("/home/cdsw")
import datetime
import sys
from pathlib import Path

import utils.mle_utils as mle_utils
import utils.Python_notebooks_Tafani_Deployment as model
import utils.sql_code as sql_code
from settings import settings
from utils.custom_logging import create_logger

logging = create_logger()


if __name__ == "__main__":

    logging.info("Creating TD connection for execute before model function")
    td_conn = mle_utils.create_teradata_connection(logging=logging)
    logging.info("Creating Hive connection for execute before model function")
    hive_conn = mle_utils.hive_connection()
    sql_code.excute_before_model(td_conn, hive_conn, logging)

    logging.info("Creating Hive connection for model function")
    hive_conn = mle_utils.hive_connection()
    model.run_model(hive_conn, logging)

    logging.info("Creating Hive connection for execute after model function")
    hive_conn = mle_utils.hive_connection()
    logging.info("Creating TD connection for execute after model function")
    td_conn = mle_utils.create_teradata_connection(logging=logging)
    sql_code.excute_after_model(td_conn, hive_conn, logging)

    logging.info("Creating TD connection for save model results function")
    td_conn = mle_utils.create_teradata_connection(logging=logging)
    sql_code.save_model_results_TD(td_conn, logging)

    logging.info(f"Cleaning data path {data_path}")
    try:
        data_path = Path(settings.data_path)
        print(data_path)
        for folder, subfolders, files in os.walk(data_path):
            for file in files:
                if file.endswith(".csv"):
                    path = os.path.join(folder, file)
                    logging.info(f"Removing file {path}")
                    os.remove(path)
    except Exception as err:
        logging.error(f" Failed to clean data path {data_path} due to error : {err}")
        sys.exit(1)
