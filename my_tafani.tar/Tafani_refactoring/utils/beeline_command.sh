#!/bin/bash 
file_path=$1
file_name=$2
table_name=$3

folder=`hdfs dfs -ls  | awk -v folder=$HDFS_FOLDER '$8 == folder  {print $8}'`


echo $folder
if [[ $folder == "$HDFS_FOLDER" ]]
then   
echo "folder exists in HDFS , uploading the file to HDFS and inserting into Hive table"
hdfs dfs -put -f $file_path $HDFS_FOLDER
# $BEELINE_BIN_HOME/beeline << EOF
# !connect jdbc:hive2://hs2-cdw-hive-sm.apps.advocprdc.stc.com.sa/dp_cad_analytics;user=$HIVE_DB_USERNAME;password=$HIVE_DB_PASSWORD;transportMode=http;httpPath=cliservice;socketTimeout=60;ssl=true;retries=3;
#     LOAD DATA INPATH "/user/$HADOOP_USER_NAME/$HDFS_FOLDER/$file_name" overwrite into table $table_name;
# !quit
# EOF
$BEELINE_BIN_HOME/beeline << EOF
    !connect jdbc:hive2://$HIVE_HOST/dp_cad_analytics;user=$HIVE_DB_USERNAME;password=$HIVE_DB_PASSWORD;transportMode=http;httpPath=cliservice;socketTimeout=60;ssl=true;retries=3;
    LOAD DATA INPATH "/user/$HADOOP_USER_NAME/$HDFS_FOLDER/$file_name" overwrite into table $table_name;
!quit
EOF
else
echo "Creating folder in HDFS , uploading the file to HDFS and inserting into Hive table"
hdfs dfs -mkdir $HDFS_FOLDER
hdfs dfs -put -f $file_path $HDFS_FOLDER
# $BEELINE_BIN_HOME/beeline << EOF
#     !connect jdbc:hive2://hs2-cdw-hive-sm.apps.advocprdc.stc.com.sa/dp_cad_analytics;user=$HIVE_DB_USERNAME;password=$HIVE_DB_PASSWORD;transportMode=http;httpPath=cliservice;socketTimeout=60;ssl=true;retries=3;
#     LOAD DATA INPATH \"$HDFS_FOLDER/$file_name\" overwrite into table $table_name;
# !quit
# EOF
$BEELINE_BIN_HOME/beeline << EOF
    !connect jdbc:hive2://$HIVE_HOST/dp_cad_analytics;user=$HIVE_DB_USERNAME;password=$HIVE_DB_PASSWORD;transportMode=http;httpPath=cliservice;socketTimeout=60;ssl=true;retries=3;
    LOAD DATA INPATH \"$HDFS_FOLDER/$file_name\" overwrite into table $table_name;
!quit
EOF
fi