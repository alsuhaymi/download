#!/usr/bin/env python
# coding: utf-8

import logging
import os
import re
import string
import time
from datetime import datetime
from datetime import datetime as dt
from datetime import timedelta

import camel_tools
import nltk
import numpy as np
import pandas as pd
from camel_tools.disambig.mle import MLEDisambiguator
from camel_tools.sentiment import SentimentAnalyzer
from camel_tools.tokenizers.morphological import MorphologicalTokenizer
from camel_tools.tokenizers.word import simple_word_tokenize
from camel_tools.utils.normalize import (
    normalize_alef_ar,
    normalize_alef_maksura_ar,
    normalize_teh_marbuta_ar,
)
from nltk.corpus import stopwords
from nltk.sentiment import SentimentIntensityAnalyzer
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk.stem.isri import ISRIStemmer
from nltk.tokenize import RegexpTokenizer, sent_tokenize, word_tokenize
from sklearn.feature_extraction import text
from sklearn.feature_extraction.text import CountVectorizer

import utils.mle_utils as mle_utils
from settings import settings
import sys


HIVE_DB_SCHEMA = settings.hive_db_schema


def removeWeirdChars(text):
    weridPatterns = re.compile(
        "["
        "\U0001F600-\U0001F64F"  # emoticons
        "\U0001F300-\U0001F5FF"  # symbols & pictographs
        "\U0001F680-\U0001F6FF"  # transport & map symbols
        "\U0001F1E0-\U0001F1FF"  # flags (iOS)
        "\U00002702-\U000027B0"
        "\U000024C2-\U0001F251"
        "\U0001f926-\U0001f937"
        "\U00010000-\U0010ffff"
        "\u200d"
        "\u2640-\u2642"
        "\u2600-\u2B55"
        "\u23cf"
        "\u23e9"
        "\u231a"
        "\u3030"
        "\ufe0f"
        "\u2069"
        "\u2066"
        "\u200c"
        "\u2068"
        "\u2067"
        "]+",
        flags=re.UNICODE,
    )
    return weridPatterns.sub(r"", text)


def preprocess_questions(text):
    text = str(text).lower()
    text = text.strip()
    text = normalize_alef_maksura_ar(text)
    text = normalize_alef_ar(text)
    text = normalize_teh_marbuta_ar(text)
    text = re.sub(r"[0-9]+", "", text)
    text = re.sub(" ", ",", text)
    text = re.sub(",", " ", text)
    text = re.sub("_", " ", text)
    text = re.sub("&", " ", text)
    text = re.sub("<.*?>", " ", text)
    text = re.sub("jawwy", "جوي", text)
    text = re.sub("جووي", "جوي", text)
    text = re.sub("qitaf", "قطاف", text)
    text = re.sub("fiber", "فايبر", text)
    text = re.sub("سوا", "sawa", text)
    text = re.sub("baity", "بيتي", text)
    text = re.sub("baiti", "بيتي", text)
    text = re.sub("iphone", "ايفون", text)
    text = re.sub("باقات", "باقه", text)
    text = re.sub("الباقه", "باقه", text)
    text = re.sub("الاتصالات", "الاتصال", text)
    text = re.sub("الفايبر", "فايبر", text)
    text = re.sub("الالياف", "الياف", text)
    text = re.sub("بالالياف", "الياف", text)
    text = re.sub("matches", "match", text)
    text = re.sub("شريحته", "شريحه", text)
    text = re.sub("الشريحه", "شريحه", text)
    text = re.sub("والحد", "الحد", text)
    text = re.sub("sawaلي", "sawa", text)
    text = re.sub("stc play", "stcplay", text)
    text = re.sub("المفوتر", "مفوتر", text)
    text = re.sub("واجهزه", "اجهزه", text)
    text = re.sub("الاجهزه", "اجهزه", text)
    text = re.sub("اجهزه", "اجهزه", text)
    text = re.sub("اجهزه", "للاجهزه", text)
    text = re.sub("اجهزه", "للاجهزه", text)
    text = re.sub("الخدمه", "خدمه", text)
    text = re.sub("\n", " ", text)
    # remove punctuations
    punctuation_Ar = """`÷×؛<>_()*&^%][ـ،/:"؟.,'{}~¦+|!”…“–ـ""" + string.punctuation
    translator = str.maketrans("", "", punctuation_Ar)
    text = text.translate(translator)
    translator = str.maketrans("", "", string.punctuation)
    text = text.translate(translator)
    text = text.strip()
    text = re.sub("stc pay", "stcpay", text)
    text = " ".join(word for word in text.split() if word not in stop_words_Ar)
    text = " ".join(word for word in text.split() if word not in stop_words_Eng)
    text = " ".join(
        word
        for word in text.split()
        if word
        not in (
            "customer",
            "عميل",
            "سلام",
            "عليكم",
            "رقم",
            "ى",
            "تم",
            "مثل",
            "قبل",
            "يمكن",
            "طلب",
            "بأن",
            "ورحمة",
            "وبركاته",
            "ان",
            "يتم",
            "او",
            "ايش",
            "ممكن",
            "يكون",
            "و",
            "وهل",
            "ماهي",
            "اخر",
            "اخرى",
            "احد",
            "الي",
            "علي",
            "_x000d_\n",
            "x000d",
            "x000d",
            "الله",
            "السلام",
            "ورحمه",
            "عدد",
            "برنامج",
            "تطبيقات",
            "تطبيق",
            "استفسار",
            "اي",
            "اذا",
            "حتي",
            "وماهي",
            "ماهو",
            "عندي",
            "لديه",
            "طريقه",
            "فقط",
            "التطبيق",
            "اكثر",
            "الان",
            "لدي",
            "help",
            "know",
            "track",
            "find",
            "منصه",
            "xd",
            "consolelogdocumentcookie",
            "وبامكانكم",
            "كيفيه",
            "اطلاعي",
            "لشخص",
            "commandcenterstcpaycomsa",
            "الرقم",
            "profile",
            "ريال",
        )
    )
    text = nltk.word_tokenize(text)
    text = [lemma.lemmatize(word) for word in text]
    pos = nltk.pos_tag(text)
    text = " ".join(
        word
        for word, tag in pos
        if tag not in ("IN", "VB", "VBZ", "CC", "DT", "JJR", "JJ")
    )
    text_list = simple_word_tokenize(text)
    disambig = mle.disambiguate(text_list)
    pos_tags = [d.analyses[0].analysis["pos"] for d in disambig]
    text = " ".join(
        [
            d.word
            for d in disambig
            if d.analyses[0].analysis["pos"]
            not in (
                "conj",
                "pron_rel",
                "abbrev",
                "verb",
                "prep",
                "punc",
                "conj_sub",
                "noun_quant",
                "pron",
                "part_neg",
                "adv_interrog",
                "pron_dem",
            )
        ]
    )
    text = re.sub("جواله", "جوال", text)
    text = " ".join(
        word
        for word in text.split()
        if word
        not in (
            "ال",
            "الاجراء",
            "اللي",
            "صباح",
            "الخير",
            "سؤالي",
            "عفوا",
            "بكل",
            "صباحكم",
            "اسعد",
            "using",
            "facing",
            "issue",
            "العملاء",
            "العميل",
            "نفس",
            "الوقت",
            "استخدام",
            "way",
            "عمل",
            "وشكرا",
            "الاتصال",
            "عبر",
            "للعميل",
            "الحاله",
            "شخص",
            "بالتفصيل",
            "طريق",
            "الاتصال",
            "البعض",
            "الافاده",
            "امكانيه",
            "والاخر",
            "احدهما",
            "بعمليه",
            "للعملاء",
            "اري",
            "مالاسباب",
            "الزملاء",
            "العميل",
            "اكثير",
            "تعديل",
            "اصدقائي",
            "المصريين",
            "مشكله",
            "عملاء",
            "اسم",
            "شركه",
            "waiting",
            "month",
            "افضل",
            "الحلول",
            "الطلب",
            "مايوقف",
            "حال",
            "لقد",
            "مكتب",
            "المبلغ",
            "فتح",
            "الجديد",
            "عدم",
            "وعند",
            "الشركه",
            "وضع",
            "اشتراك",
            "الاستفاده",
            "الطريقه",
            "بالعملاء",
            "لنفس",
            "شكرا",
            "جديد",
            "زملائي",
            "one",
            "yes",
            "already",
            "الخاصه",
            "متوفر",
            "وليس",
            "باسم",
            "المستخدم",
            "فهمها",
            "استخراج",
            "مناطق",
            "بدون",
            " شاكر",
            "anyone",
            "تقريبا",
            "باسمها",
            "ملاحظه",
            "soon",
            "happening",
            "المطلوبه",
            "موجوده",
            "الحاليه",
            "وقت",
            "اسرع",
            "مركز",
            "ء",
            "get",
            "getting",
            "ksa",
            "stc",
            "باقه",
            "الارقام",
            "مبلغ",
            "الاستخدام",
            "طويله",
            "ايضا",
            "لمده",
            "لايوجد",
            "زياده",
            "سداد",
            "عادل",
            "لباقه",
            "العنايه",
            "الاشتراكات",
            "الاستخدام",
            "ماعندي",
            "بعميل",
            "خدمه",
        )
    )
    text = re.sub("اجهزه", "للاجهزه", text)
    text = re.sub("جوي جوي", "جوي", text)
    if text.startswith("ال"):
        text = text[2:]
    if " الي" not in text:
        text = re.sub(" ال", " ", text)
    text = re.sub(" وال", " و", text)
    text = " ".join(
        word
        for word in text.split()
        if word
        not in (
            "service",
            "call",
            "شرايح",
            "وكلمه",
            "استثنائها",
            "رقمين",
            "المقدمه",
            "مده",
            "بامكاني",
            "شريحه",
            "للاجهزه",
            "للللللاجهزه",
            "حل",
            "بسبب",
            "واجهزه",
            "للاجهزه",
            "سريع",
            "جهاز",
            "لايقبل",
            "جوال",
            "الاجهزه",
            "اكبر",
            "بالامكان",
            "شهر",
            "حساب",
            "ووقوف",
            "منطقه دمام",
            "بخصوص",
            "صاحب",
            "عاديه",
            "وكيفيه",
            "وجود",
            "مناسبه",
            "مملكه",
            "مبالغ",
            "كثير",
            "فضلا",
            "سكنيه",
            "ارسال",
            "للللللللاجهزه",
            "حاليا",
            "منطقه دمام",
            "لديها",
            "منطقه",
            "دمام",
            "package",
            "app",
            "توفير",
            "ولخدمه",
            "مبني",
            "سعوديه",
            "مرات",
            "عده",
            "حضور",
            "مفوترهبنفس",
            "توصيل",
            "تحويله",
            "اداره",
            "استبداله",
            "كاش",
            "اقصاد",
            "مزايا",
            "pick",
            "line",
            "زمنيه",
            "عامه",
            "اماكن",
            "جداسنتين",
            "httpshcmsapsfcomlogincompanystc",
            "\n\n",
            "\n",
        )
    )
    text = text.strip()
    return text


def preprocess_questions_2(text):
    text = text.lower()
    text = text.strip()
    text = normalize_alef_maksura_ar(text)
    text = normalize_alef_ar(text)
    text = normalize_teh_marbuta_ar(text)
    text = re.sub("_x000d_", " ", text)
    text = " ".join(
        word
        for word in text.split()
        if word not in ("_x000d_\n", "x000d", "x000d", "_x000d_", "_x000d_")
    )
    text = text.strip()
    return text


def sentiment(text):
    sia = SentimentIntensityAnalyzer()
    sentiment = pd.DataFrame(list(sia.polarity_scores(text).items()))
    sentiment.rename(columns={0: "SA", 1: "prob"}, inplace=True)
    sentiment = sentiment[(sentiment["SA"] != "compound")]
    sentiment["SA"][(sentiment["prob"] == sentiment["prob"].max())].values[0]
    return sentiment["SA"][(sentiment["prob"] == sentiment["prob"].max())].values[0]


# def sentiment(text):
#     text = sa.predict(text)
#     return text[0]


# def run_model(hive_conn, logging):
#     try:
#         logging.info("Starting Model Function")
#         # TD_DB_SCHEMA=os.environ.get("TD_DB_SCHEMA")
#         # HIVE_DB_SCHEMA=os.environ.get("HIVE_DB_SCHEMA")

#         hive_conn = mle_utils.hive_connection()

#         logging.info(f"Reading {HIVE_DB_SCHEMA}.TAFANI_Question_CML")
#         stmt = f"select * from {HIVE_DB_SCHEMA}.TAFANI_Question_CML  WHERE question_id IS NOT NULL"
#         Questions = pd.read_sql(con=hive_conn, sql=stmt)

#         Questions.columns = Questions.columns.str.upper()
#         Questions.set_index("QUESTION_ID", inplace=True)
#         Questions.to_csv("Questions.csv")
#         logging.info(
#             "---------------Questions DF Created--------------------------------------------------------------------------"
#         )

#         logging.info(f"Reading {HIVE_DB_SCHEMA}.TAFANI_Question_CML")
#         stmt2 = f"select * from {HIVE_DB_SCHEMA}.tafani_analytics_cml"
#         TAFANI_Analytics = pd.read_sql(con=hive_conn, sql=stmt2)
#         TAFANI_Analytics.columns = TAFANI_Analytics.columns.str.upper()
#         TAFANI_Analytics.set_index("QUESTION_ID", inplace=True)
#         TAFANI_Analytics.to_csv("TAFANI_Analytics.csv")
#         logging.info(
#             "------------TAFANI ANALYTICS DF Created------------------------------------------------------------------------"
#         )
#         logging.info("Starting Data preparation")

#         # Preparation

#         Questions["KEY_WORD_processed"] = (
#             Questions["QUESTION_TEXT_AR"] + " " + Questions["KEY_WORD"].fillna("")
#         )
#         Questions["KEY_WORD_processed"].fillna("Other", inplace=True)
#         Questions["KEY_WORD_processed"] = Questions["KEY_WORD_processed"][
#             (Questions["KEY_WORD_processed"] != "Others")
#         ]

#         Questions["KEY_WORD_processed"] = Questions["KEY_WORD_processed"].apply(
#             removeWeirdChars
#         )

#         punctuation_Ar = """`÷×؛<>_()*&^%][ـ،/:"؟.,'{}~¦+|!”…“–ـ""" + string.punctuation

#         stop_words_Ar = stopwords.words("arabic")
#         stop_words_Eng = stopwords.words("english")
#         lemma = WordNetLemmatizer()
#         ps = PorterStemmer()
#         st = ISRIStemmer()
#         mle = MLEDisambiguator.pretrained()

#         Questions["KEY_WORD_processed"] = Questions["KEY_WORD_processed"].apply(
#             preprocess_questions
#         )
#         Questions["KEY_WORD_2"] = Questions["KEY_WORD"].str.translate(
#             str.maketrans("", "", punctuation_Ar)
#         )
#         Questions["KEY_WORD_2"] = Questions["KEY_WORD_2"].str.translate(
#             str.maketrans("", "", string.punctuation)
#         )
#         Questions = Questions.reset_index()
#         Questions["id"] = np.arange(0, len(Questions))

#         vectorizer = CountVectorizer(ngram_range=(1, 2))
#         X = vectorizer.fit_transform(Questions["KEY_WORD_processed"])
#         vectorizer.get_feature_names_out()
#         tf = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
#         tf = tf.stack().reset_index()
#         tf = tf.rename(
#             columns={
#                 0: "tf",
#                 "level_0": "question",
#                 "level_1": "term",
#                 "level_2": "term",
#             }
#         )
#         tf = tf[(tf["tf"] > 0)]
#         tf["term_cnt_words"] = (tf["term"].str.split()).str.len()

#         tf_final = tf.groupby(["term"])["tf"].agg(sum).reset_index()
#         tf_final.sort_values(by=["tf"], ascending=False)
#         tf_final["term_cnt_words"] = (tf_final["term"].str.split()).str.len()
#         tf_mreged = tf.merge(tf_final[["term", "tf"]], left_on="term", right_on="term")

#         Q_term_1ngram = (
#             tf_mreged[(tf_mreged["term_cnt_words"] == 1)]
#             .sort_values(by=["question", "tf_y", "tf_x"], ascending=False)
#             .groupby(["question"])
#             .head(2)
#         )
#         Q_term_1ngram = Q_term_1ngram[["question", "term"]]
#         Q_term_1ngram_final = Q_term_1ngram.groupby(["question"]).head(1)
#         Q_term_1ngram_final = Q_term_1ngram_final.merge(
#             Q_term_1ngram.groupby(["question"]).tail(1),
#             how="left",
#             left_on="question",
#             right_on="question",
#         )
#         Q_term_1ngram_final = Q_term_1ngram_final.rename(
#             columns={"term_x": "term_1", "term_y": "term_2"}
#         )

#         Q_term_2ngram = (
#             tf_mreged[(tf_mreged["term_cnt_words"] == 2)]
#             .sort_values(by=["question", "tf_y", "tf_x"], ascending=False)
#             .groupby(["question"])
#             .head(50)
#         )
#         tf_results = Q_term_1ngram_final.merge(
#             Q_term_2ngram[["question", "term"]],
#             how="left",
#             left_on="question",
#             right_on="question",
#         )
#         tf_results.rename(columns={"term": "detailed_term2"}, inplace=True)

#         tf_results["term_1_compr2"] = tf_results.apply(
#             lambda x: str(x.term_1) in str(x.detailed_term2), axis=1
#         )
#         tf_results["term_2_compr2"] = tf_results.apply(
#             lambda x: str(x.term_2) in str(x.detailed_term2), axis=1
#         )
#         tf_results2 = (
#             tf_results[
#                 (tf_results["term_1_compr2"] == True)
#                 & (tf_results["term_2_compr2"] == True)
#             ]
#             .groupby(["question"])
#             .head(1)
#         )

#         tf_results2 = tf_results2.merge(
#             Questions, how="right", left_on="question", right_on="id"
#         )
#         tf_results3 = (
#             tf_results2[(tf_results2["question"].isna())]
#             .merge(
#                 tf_results[["question", "term_1", "term_2", "detailed_term2"]][
#                     (tf_results["term_1_compr2"] == True)
#                     | (tf_results["term_2_compr2"] == True)
#                 ],
#                 how="left",
#                 left_on="id",
#                 right_on="question",
#             )
#             .groupby(["id"])
#             .head(1)
#         )

#         tf_results2 = tf_results2.merge(
#             tf_results3[["question_y", "term_1_y", "term_2_y", "detailed_term2_y"]],
#             how="left",
#             left_on="id",
#             right_on="question_y",
#         )
#         tf_results2["question"][(tf_results2["question"].isna())] = tf_results2[
#             "question_y"
#         ]
#         tf_results2["term_1"][(tf_results2["term_1"].isna())] = tf_results2["term_1_y"]
#         tf_results2["term_2"][(tf_results2["term_2"].isna())] = tf_results2["term_2_y"]
#         tf_results2["detailed_term2"][(tf_results2["detailed_term2"].isna())] = (
#             tf_results2["detailed_term2_y"]
#         )

#         tf_results2["term_1"][
#             ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
#         ] = tf_results2["KEY_WORD_processed"][
#             ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
#         ]
#         tf_results2["detailed_term2"][
#             ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
#         ] = tf_results2["KEY_WORD_processed"][
#             ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
#         ]
#         tf_results2["question"][
#             ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
#         ] = tf_results2["id"][
#             ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
#         ]

#         tf_results = tf_results2
#         tf_results["term1_final"] = tf_results["term_1"]
#         tf_results["term2_final"] = tf_results["term_2"]
#         tf_results["term1_final"][
#             (
#                 tf_results["term_2"].isin(
#                     [
#                         "gaming",
#                         "stcpay",
#                         "جوي",
#                         "فايبر",
#                         "قطاف",
#                         "مفوتر",
#                         "كويك",
#                         "تفاني",
#                         "ايفون",
#                     ]
#                 )
#             )
#             & (
#                 ~tf_results["term_1"].isin(
#                     [
#                         "gaming",
#                         "stcpay",
#                         "جوي",
#                         "فايبر",
#                         "قطاف",
#                         "مفوتر",
#                         "كويك",
#                         "تفاني",
#                         "ايفون",
#                     ]
#                 )
#             )
#         ] = tf_results["term_2"]

#         tf_ngrams = tf_results.copy()
#         tf_ngrams = tf_ngrams.reset_index()
#         tf_ngrams["id"] = np.arange(0, len(tf_ngrams))

#         vectorizer = CountVectorizer(ngram_range=(1, 2))
#         X = vectorizer.fit_transform(tf_ngrams["KEY_WORD_processed"])
#         vectorizer.get_feature_names_out()
#         tf = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
#         tf = tf.stack().reset_index()
#         tf = tf.rename(columns={0: "tf", "level_0": "Question", "level_1": "term"})
#         tf = tf[(tf["tf"] > 0)]
#         tf["term_cnt_words"] = (tf["term"].str.split()).str.len()

#         tf_final = tf.groupby(["term"])["tf"].agg(sum).reset_index()
#         tf_final.sort_values(by=["tf"], ascending=False)
#         tf_final["term_length"] = (tf_final["term"].str.split()).str.len()
#         tf_mreged = tf.merge(tf_final[["term", "tf"]], left_on="term", right_on="term")

#         results_1ngram = tf_mreged[(tf_mreged["term_cnt_words"] == 1)].merge(
#             tf_ngrams, how="right", left_on="Question", right_on="id"
#         )
#         results_1ngram.rename(
#             columns={"tf_y": "Count", "term": "Key_Word"}, inplace=True
#         )
#         results_1ngram["Key_Word"][(results_1ngram["Question"] == "Others")] = np.NaN
#         results_1ngram["Count"][(results_1ngram["Question"] == "Others")] = np.NaN
#         results_1ngram["Question"][(results_1ngram["Question"] == "Others")] = np.NaN

#         results_2ngram = tf_mreged[(tf_mreged["term_cnt_words"] == 2)].merge(
#             tf_ngrams, how="right", left_on="Question", right_on="id"
#         )
#         results_2ngram.rename(
#             columns={"tf_y": "Count", "term": "Key_Word"}, inplace=True
#         )
#         results_2ngram["Key_Word"][(results_2ngram["Question"] == "Others")] = np.NaN
#         results_2ngram["Count"][(results_2ngram["Question"] == "Others")] = np.NaN
#         results_2ngram["Question"][(results_2ngram["Question"] == "Others")] = np.NaN

#         results_1ngram[
#             [
#                 "Key_Word",
#                 "QUESTION_ID",
#                 "QUESTION_TEXT_AR",
#                 "QUESTION_TEXT_EN",
#                 "USER_ID",
#                 "USER_EMAIL",
#                 "CATEGORY_ID",
#                 "SUB_CATEGORY_ID",
#                 "LEVEL3_SUB_CATEGORY_ID",
#                 "LEVEL4_SUB_CATEGORY_ID",
#                 "KEY_WORD",
#                 "QUESTION_DATE",
#                 "QUESTION_TIME",
#             ]
#         ][(results_1ngram["Count"] != 1)].to_excel(
#             r"results_1ngram.xlsx", sheet_name="1ngram", index=False
#         )
#         results_2ngram[
#             [
#                 "Key_Word",
#                 "QUESTION_ID",
#                 "QUESTION_TEXT_AR",
#                 "QUESTION_TEXT_EN",
#                 "USER_ID",
#                 "USER_EMAIL",
#                 "CATEGORY_ID",
#                 "SUB_CATEGORY_ID",
#                 "LEVEL3_SUB_CATEGORY_ID",
#                 "LEVEL4_SUB_CATEGORY_ID",
#                 "KEY_WORD",
#                 "QUESTION_DATE",
#                 "QUESTION_TIME",
#             ]
#         ].to_excel(r"results_2ngram.xlsx", sheet_name="2ngram", index=False)

#         tf_results = tf_results[
#             ~(tf_results["QUESTION_ID"].isin(TAFANI_Analytics.index))
#         ]
#         tf_results["term1_final"][(tf_results["question"].isna())] = (
#             tf_results["KEY_WORD_2"][(tf_results["question"].isna())]
#             .str.split(" ")
#             .str[0]
#         )
#         tf_results["detailed_term2"][(tf_results["question"].isna())] = (
#             tf_results["KEY_WORD_2"][(tf_results["question"].isna())]
#             .str.split(" ")
#             .str[0]
#             + " "
#             + tf_results["KEY_WORD_2"][(tf_results["question"].isna())]
#             .str.split(" ")
#             .str[1]
#         )

#         tf_results["QUESTION_TEXT_AR_2"] = tf_results["QUESTION_TEXT_AR"].apply(
#             preprocess_questions_2
#         )

#         sia = SentimentIntensityAnalyzer()

#         tf_results["sentiment1_1"] = tf_results["KEY_WORD_processed"].apply(sentiment)
#         tf_results["sentiment1_2"] = tf_results["QUESTION_TEXT_AR_2"].apply(sentiment)

#         sa = SentimentAnalyzer.pretrained()

#         tf_results["sentiment2_1"] = tf_results["KEY_WORD_processed"].apply(sentiment)
#         tf_results["sentiment2_2"] = tf_results["QUESTION_TEXT_AR_2"].apply(sentiment)

#         tf_results["sentiment"] = "neutral"
#         tf_results["sentiment"][
#             (tf_results["sentiment2_1"] == "negative")
#             & (tf_results["sentiment2_2"] == "negative")
#         ] = "negative"

#         searchfor = [
#             "يشتكى",
#             "مشكله",
#             "شكوى",
#             "يشكى",
#             "سوء",
#             "issue",
#             "اعطال",
#             "بلاغ",
#             "عطل",
#         ]
#         tf_results["sentiment"][
#             (tf_results["QUESTION_TEXT_AR_2"].str.contains("|".join(searchfor)))
#         ] = "negative"

#         searchfor2 = ["idea", "فكره", "اقتراح"]
#         tf_results["NLU"] = "Enquiry"
#         tf_results["NLU"][
#             (tf_results["QUESTION_TEXT_AR_2"].str.contains("|".join(searchfor2)))
#         ] = "Idea"

#         tf_results["NLU"][
#             (tf_results["QUESTION_TEXT_AR_2"].str.contains("|".join(searchfor)))
#         ] = "Issue"  # .groupby(['sentiment']).agg('count').reset_index()
#         tf_results["NLU"][(tf_results["sentiment"] == "negative")] = "Issue"

#         final_results = tf_results[
#             ["QUESTION_ID", "term1_final", "detailed_term2", "sentiment", "NLU"]
#         ]

#         final_results = final_results.fillna(0)
#         final_results.to_csv(os.path.join(settings.data_path, settings.output_final_file), index=False)

#         logging.info("Start inserting model result data into hive table")
#         table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Analytics_CML"
#         mle_utils.insert_data_hive(table_name, final_results)
#         logging.info("Finish inserting model result data into hive table")
#         hive_conn.close()

#     except Exception as err:
#         logging.error("err")
#         sys.exit(1)


def run_model(spark_conn):
    try:
        logging.info("Starting Model Function")

        logging.info(f"Reading {HIVE_DB_SCHEMA}.TAFANI_Question_CML")
        stmt = f"select * from {HIVE_DB_SCHEMA}.TAFANI_Question_CML  WHERE question_id IS NOT NULL"
        Questions = spark_conn.sql(stmt).toPandas()

        logging.info(f"[debug] - size of pandas df {Questions.shape}")
        Questions.columns = Questions.columns.str.upper()
        Questions.set_index("QUESTION_ID", inplace=True)
        Questions.to_csv("Questions.csv")
        logging.info(
            "---------------Questions DF Created--------------------------------------------------------------------------"
        )

        logging.info(f"Reading {HIVE_DB_SCHEMA}.TAFANI_Question_CML")
        stmt2 = f"select * from {HIVE_DB_SCHEMA}.tafani_analytics_cml"
        TAFANI_Analytics = spark_conn.sql(stmt2).toPandas()

        TAFANI_Analytics.columns = TAFANI_Analytics.columns.str.upper()
        TAFANI_Analytics.set_index("QUESTION_ID", inplace=True)
        TAFANI_Analytics.to_csv("TAFANI_Analytics.csv")
        logging.info(
            "------------TAFANI ANALYTICS DF Created------------------------------------------------------------------------"
        )
        logging.info("Starting Data preparation")

        # Preparation
        logging.info("[DEBUG] preprocessing KEY_WORD_processed")
        Questions["KEY_WORD_processed"] = (
            Questions["QUESTION_TEXT_AR"] + " " + Questions["KEY_WORD"].fillna("")
        )
        Questions["KEY_WORD_processed"].fillna("Other", inplace=True)
        Questions["KEY_WORD_processed"] = Questions["KEY_WORD_processed"][
            (Questions["KEY_WORD_processed"] != "Others")
        ]

        Questions["KEY_WORD_processed"] = Questions["KEY_WORD_processed"].apply(
            removeWeirdChars
        )

        punctuation_Ar = """`÷×؛<>_()*&^%][ـ،/:"؟.,'{}~¦+|!”…“–ـ""" + string.punctuation

        stop_words_Ar = stopwords.words("arabic")
        stop_words_Eng = stopwords.words("english")
        lemma = WordNetLemmatizer()
        ps = PorterStemmer()
        st = ISRIStemmer()
        mle = MLEDisambiguator.pretrained()

        Questions["KEY_WORD_processed"] = Questions["KEY_WORD_processed"].apply(
            preprocess_questions
        )
        Questions["KEY_WORD_2"] = Questions["KEY_WORD"].str.translate(
            str.maketrans("", "", punctuation_Ar)
        )
        Questions["KEY_WORD_2"] = Questions["KEY_WORD_2"].str.translate(
            str.maketrans("", "", string.punctuation)
        )
        Questions = Questions.reset_index()
        Questions["id"] = np.arange(0, len(Questions))

        vectorizer = CountVectorizer(ngram_range=(1, 2))
        X = vectorizer.fit_transform(Questions["KEY_WORD_processed"])
        vectorizer.get_feature_names_out()
        tf = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
        tf = tf.stack().reset_index()
        tf = tf.rename(
            columns={
                0: "tf",
                "level_0": "question",
                "level_1": "term",
                "level_2": "term",
            }
        )
        tf = tf[(tf["tf"] > 0)]
        tf["term_cnt_words"] = (tf["term"].str.split()).str.len()

        tf_final = tf.groupby(["term"])["tf"].agg(sum).reset_index()
        tf_final.sort_values(by=["tf"], ascending=False)
        tf_final["term_cnt_words"] = (tf_final["term"].str.split()).str.len()
        tf_mreged = tf.merge(tf_final[["term", "tf"]], left_on="term", right_on="term")

        Q_term_1ngram = (
            tf_mreged[(tf_mreged["term_cnt_words"] == 1)]
            .sort_values(by=["question", "tf_y", "tf_x"], ascending=False)
            .groupby(["question"])
            .head(2)
        )
        Q_term_1ngram = Q_term_1ngram[["question", "term"]]
        Q_term_1ngram_final = Q_term_1ngram.groupby(["question"]).head(1)
        Q_term_1ngram_final = Q_term_1ngram_final.merge(
            Q_term_1ngram.groupby(["question"]).tail(1),
            how="left",
            left_on="question",
            right_on="question",
        )
        Q_term_1ngram_final = Q_term_1ngram_final.rename(
            columns={"term_x": "term_1", "term_y": "term_2"}
        )

        Q_term_2ngram = (
            tf_mreged[(tf_mreged["term_cnt_words"] == 2)]
            .sort_values(by=["question", "tf_y", "tf_x"], ascending=False)
            .groupby(["question"])
            .head(50)
        )
        tf_results = Q_term_1ngram_final.merge(
            Q_term_2ngram[["question", "term"]],
            how="left",
            left_on="question",
            right_on="question",
        )
        tf_results.rename(columns={"term": "detailed_term2"}, inplace=True)

        tf_results["term_1_compr2"] = tf_results.apply(
            lambda x: str(x.term_1) in str(x.detailed_term2), axis=1
        )
        tf_results["term_2_compr2"] = tf_results.apply(
            lambda x: str(x.term_2) in str(x.detailed_term2), axis=1
        )
        tf_results2 = (
            tf_results[
                (tf_results["term_1_compr2"] == True)
                & (tf_results["term_2_compr2"] == True)
            ]
            .groupby(["question"])
            .head(1)
        )

        tf_results2 = tf_results2.merge(
            Questions, how="right", left_on="question", right_on="id"
        )
        tf_results3 = (
            tf_results2[(tf_results2["question"].isna())]
            .merge(
                tf_results[["question", "term_1", "term_2", "detailed_term2"]][
                    (tf_results["term_1_compr2"] == True)
                    | (tf_results["term_2_compr2"] == True)
                ],
                how="left",
                left_on="id",
                right_on="question",
            )
            .groupby(["id"])
            .head(1)
        )

        tf_results2 = tf_results2.merge(
            tf_results3[["question_y", "term_1_y", "term_2_y", "detailed_term2_y"]],
            how="left",
            left_on="id",
            right_on="question_y",
        )
        tf_results2["question"][(tf_results2["question"].isna())] = tf_results2[
            "question_y"
        ]
        tf_results2["term_1"][(tf_results2["term_1"].isna())] = tf_results2["term_1_y"]
        tf_results2["term_2"][(tf_results2["term_2"].isna())] = tf_results2["term_2_y"]
        tf_results2["detailed_term2"][(tf_results2["detailed_term2"].isna())] = (
            tf_results2["detailed_term2_y"]
        )

        tf_results2["term_1"][
            ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
        ] = tf_results2["KEY_WORD_processed"][
            ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
        ]
        tf_results2["detailed_term2"][
            ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
        ] = tf_results2["KEY_WORD_processed"][
            ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
        ]
        tf_results2["question"][
            ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
        ] = tf_results2["id"][
            ((tf_results2["KEY_WORD_processed"].str.split()).str.len() == 1)
        ]

        tf_results = tf_results2
        tf_results["term1_final"] = tf_results["term_1"]
        tf_results["term2_final"] = tf_results["term_2"]
        tf_results["term1_final"][
            (
                tf_results["term_2"].isin(
                    [
                        "gaming",
                        "stcpay",
                        "جوي",
                        "فايبر",
                        "قطاف",
                        "مفوتر",
                        "كويك",
                        "تفاني",
                        "ايفون",
                    ]
                )
            )
            & (
                ~tf_results["term_1"].isin(
                    [
                        "gaming",
                        "stcpay",
                        "جوي",
                        "فايبر",
                        "قطاف",
                        "مفوتر",
                        "كويك",
                        "تفاني",
                        "ايفون",
                    ]
                )
            )
        ] = tf_results["term_2"]

        tf_ngrams = tf_results.copy()
        tf_ngrams = tf_ngrams.reset_index()
        tf_ngrams["id"] = np.arange(0, len(tf_ngrams))

        vectorizer = CountVectorizer(ngram_range=(1, 2))
        X = vectorizer.fit_transform(tf_ngrams["KEY_WORD_processed"])
        vectorizer.get_feature_names_out()
        tf = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
        tf = tf.stack().reset_index()
        tf = tf.rename(columns={0: "tf", "level_0": "Question", "level_1": "term"})
        tf = tf[(tf["tf"] > 0)]
        tf["term_cnt_words"] = (tf["term"].str.split()).str.len()

        tf_final = tf.groupby(["term"])["tf"].agg(sum).reset_index()
        tf_final.sort_values(by=["tf"], ascending=False)
        tf_final["term_length"] = (tf_final["term"].str.split()).str.len()
        tf_mreged = tf.merge(tf_final[["term", "tf"]], left_on="term", right_on="term")

        results_1ngram = tf_mreged[(tf_mreged["term_cnt_words"] == 1)].merge(
            tf_ngrams, how="right", left_on="Question", right_on="id"
        )
        results_1ngram.rename(
            columns={"tf_y": "Count", "term": "Key_Word"}, inplace=True
        )
        results_1ngram["Key_Word"][(results_1ngram["Question"] == "Others")] = np.NaN
        results_1ngram["Count"][(results_1ngram["Question"] == "Others")] = np.NaN
        results_1ngram["Question"][(results_1ngram["Question"] == "Others")] = np.NaN

        results_2ngram = tf_mreged[(tf_mreged["term_cnt_words"] == 2)].merge(
            tf_ngrams, how="right", left_on="Question", right_on="id"
        )
        results_2ngram.rename(
            columns={"tf_y": "Count", "term": "Key_Word"}, inplace=True
        )
        results_2ngram["Key_Word"][(results_2ngram["Question"] == "Others")] = np.NaN
        results_2ngram["Count"][(results_2ngram["Question"] == "Others")] = np.NaN
        results_2ngram["Question"][(results_2ngram["Question"] == "Others")] = np.NaN

        results_1ngram[
            [
                "Key_Word",
                "QUESTION_ID",
                "QUESTION_TEXT_AR",
                "QUESTION_TEXT_EN",
                "USER_ID",
                "USER_EMAIL",
                "CATEGORY_ID",
                "SUB_CATEGORY_ID",
                "LEVEL3_SUB_CATEGORY_ID",
                "LEVEL4_SUB_CATEGORY_ID",
                "KEY_WORD",
                "QUESTION_DATE",
                "QUESTION_TIME",
            ]
        ][(results_1ngram["Count"] != 1)].to_excel(
            r"results_1ngram.xlsx", sheet_name="1ngram", index=False
        )
        results_2ngram[
            [
                "Key_Word",
                "QUESTION_ID",
                "QUESTION_TEXT_AR",
                "QUESTION_TEXT_EN",
                "USER_ID",
                "USER_EMAIL",
                "CATEGORY_ID",
                "SUB_CATEGORY_ID",
                "LEVEL3_SUB_CATEGORY_ID",
                "LEVEL4_SUB_CATEGORY_ID",
                "KEY_WORD",
                "QUESTION_DATE",
                "QUESTION_TIME",
            ]
        ].to_excel(r"results_2ngram.xlsx", sheet_name="2ngram", index=False)

        tf_results = tf_results[
            ~(tf_results["QUESTION_ID"].isin(TAFANI_Analytics.index))
        ]
        tf_results["term1_final"][(tf_results["question"].isna())] = (
            tf_results["KEY_WORD_2"][(tf_results["question"].isna())]
            .str.split(" ")
            .str[0]
        )
        tf_results["detailed_term2"][(tf_results["question"].isna())] = (
            tf_results["KEY_WORD_2"][(tf_results["question"].isna())]
            .str.split(" ")
            .str[0]
            + " "
            + tf_results["KEY_WORD_2"][(tf_results["question"].isna())]
            .str.split(" ")
            .str[1]
        )

        tf_results["QUESTION_TEXT_AR_2"] = tf_results["QUESTION_TEXT_AR"].apply(
            preprocess_questions_2
        )

        sia = SentimentIntensityAnalyzer()

        tf_results["sentiment1_1"] = tf_results["KEY_WORD_processed"].apply(sentiment)
        tf_results["sentiment1_2"] = tf_results["QUESTION_TEXT_AR_2"].apply(sentiment)

        sa = SentimentAnalyzer.pretrained()

        tf_results["sentiment2_1"] = tf_results["KEY_WORD_processed"].apply(sentiment)
        tf_results["sentiment2_2"] = tf_results["QUESTION_TEXT_AR_2"].apply(sentiment)

        tf_results["sentiment"] = "neutral"
        tf_results["sentiment"][
            (tf_results["sentiment2_1"] == "negative")
            & (tf_results["sentiment2_2"] == "negative")
        ] = "negative"

        searchfor = [
            "يشتكى",
            "مشكله",
            "شكوى",
            "يشكى",
            "سوء",
            "issue",
            "اعطال",
            "بلاغ",
            "عطل",
        ]
        tf_results["sentiment"][
            (tf_results["QUESTION_TEXT_AR_2"].str.contains("|".join(searchfor)))
        ] = "negative"

        searchfor2 = ["idea", "فكره", "اقتراح"]
        tf_results["NLU"] = "Enquiry"
        tf_results["NLU"][
            (tf_results["QUESTION_TEXT_AR_2"].str.contains("|".join(searchfor2)))
        ] = "Idea"

        tf_results["NLU"][
            (tf_results["QUESTION_TEXT_AR_2"].str.contains("|".join(searchfor)))
        ] = "Issue"  # .groupby(['sentiment']).agg('count').reset_index()
        tf_results["NLU"][(tf_results["sentiment"] == "negative")] = "Issue"

        final_results = tf_results[
            ["QUESTION_ID", "term1_final", "detailed_term2", "sentiment", "NLU"]
        ]

        final_results = final_results.fillna(0)
        final_results.to_csv(
            os.path.join(settings.data_path, settings.output_final_file), index=False
        )

        logging.info("Start inserting model result data into hive table")
        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Analytics_CML"
        mle_utils.insert_data_hive(table_name, final_results)
        logging.info("Finish inserting model result data into hive table")

    except Exception as err:
        logging.error("err")
        sys.exit(1)
