import logging
import subprocess
from sys import getdefaultencoding

ENCODING = getdefaultencoding()


def hdfs_put(src, dst, force=False):
    """
    Envoi le fichier src sur HDFS dans le dossier dst.

    Args:
        src (str): chemin du fichier à envoyer
        dst (str): chemin du dossier de destination sur HDFS
        force (bool, optional): Overwrite le fichier de destination s'il existe. Defaults to False.

    Returns:
        bool: True si pas d'erreur, sinon False
    """
    logging.info("Export HDFS :%s to %s", src, dst)

    cmd = [
        "hdfs",
        "dfs",
        "-put",
    ]
    if force:
        cmd.append("-f")
    cmd += [src, dst]

    output = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False
    )

    out = False
    if output.returncode == 0:
        logging.info("File transfered from %s to hdfs : %s", src, dst)
        out = True
    else:
        logging.error(
            f"""Error while transfering file from {src} to hdfs {dst} : {output.stdout.decode(ENCODING) }"""
        )

    return out


def hdfs_get(path_hdfs, path_local):
    """
    Récupère le fichier path_hdfs depuis HDFS et le copie en local dans path_local.

    Args:
        path_hdfs (str): Chemin sur HDFS
        path_local (str): Chemin en local

    Returns:
        bool: True si pas d'erreur, sinon False
    """
    cmd = ["hdfs", "dfs", "-get", path_hdfs, path_local]

    output = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False
    )

    out = False
    if output.returncode == 0:
        logging.info(
            "File transfered from hdfs %s to local path : %s",
            path_hdfs,
            path_local,
        )
        out = True
    else:
        logging.error(
            f"Error while transfering file from hdfs {path_hdfs} to local directory {path_local} :  {output.stdout.decode(ENCODING) }"
        )
    return out


def ls_hdfs(path_hdfs):
    """
    Liste les fichiers présents sur HDFS.

    Args:
        path_hdfs (str): Chemin sur HDFS

    Returns:
        list: Liste des fichiers
    """
    cmd = ["hdfs", "dfs", "-ls", path_hdfs]
    proc = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False
    )
    file_list = [
        x.split(" ")[-1] for x in proc.stdout.decode(ENCODING).split("\n")[1:-1]
    ]

    return file_list


def hdfs_test(path_hdfs, file_or_dir="-e"):
    """
    Test that the hdfs path exists

    Args:
        path_hdfs (str): Chemin sur HDFS
        file_or_dir (str): option pour vérifier la présence d'un fichier ("-e") ou d'un répertoire ("-d")

    Returns:
        Bool: True if the path exists, else False
    """
    logging.info(f"[debug] - testing if file {path_hdfs} exists")
    cmd = ["hdfs", "dfs", "-test", file_or_dir, path_hdfs]
    output = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False
    )
    logging.info(f"[debug] - file exists: {output}")

    return output.returncode == 0


def hdfs_mkdir(path_hdfs, parents=False):
    """
    Create directory in hdfs

    Args:
        path_hdfs (str): Chemin sur HDFS

    Returns:
        Bool: True if the path has been created, else False
    """
    cmd = [
        "hdfs",
        "dfs",
        "-mkdir",
    ]
    if parents:
        cmd.append("-p")
    cmd.append(path_hdfs)

    output = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False
    )

    out = False
    if output.returncode == 0:
        logging.info("hdfs directory %s created", path_hdfs)
        out = True
    else:
        logging.error("Error while creating hdfs directory %s ", path_hdfs)
    return out


def hdfs_mv(src, dest):
    """
    Move file from src to dest

    Args:
        src (str): Source file
        dest (str): Destination path

    Returns:
        Bool: True si pas d'erreur, sinon False
    """
    cmd = ["hdfs", "dfs", "-mv", src, dest]

    output = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False
    )

    out = False
    if output.returncode == 0:
        logging.info(f"hdfs file transfered  from {src} to {dest} ")
        out = True
    else:
        logging.error(
            f"Error while moving hdfs file from {src} to {dest} : {output.stdout.decode(ENCODING) } "
        )
    return out
