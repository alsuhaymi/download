import logging
import os
from datetime import datetime
from pathlib import Path


def setup_logger(log_level, log_dir, log_file_name):
    """
    Configure application logger.

    Use log file and consol to print messages

    Args:
        log_level (str): log level
        log_dir (str): path to the log directory
        log_file_name (str): name of the log file

    Returns:
        tuple(str, str): path to log and database
    """
    base = Path(log_file_name).stem
    extension = Path(log_file_name).suffix

    log_file_path = os.path.join(
        log_dir,
        datetime.now().strftime(base + "_%Y_%m_%d_%H_%M_%S" + extension),
    )
    log_file_database_path = os.path.join(
        log_dir,
        datetime.now().strftime(base + "_database_%Y_%m_%d_%H_%M_%S" + extension),
    )

    # Database logger
    logger_database = logging.getLogger("data_accessor")
    logger_database.propagate = False
    fh_db = logging.FileHandler(log_file_database_path)
    fh_db.setLevel(log_level)

    # Root Logger -> Will disable all loggers called after this
    logger = logging.getLogger()
    logger.setLevel(log_level)

    # Set File Logger
    file_handler = logging.FileHandler(log_file_path)
    file_handler.setLevel(log_level)

    # Stream handler
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(log_level)

    # Formatter
    formatter = logging.Formatter("%(asctime)s - %(module)s - %(message)s")
    file_handler.setFormatter(formatter)
    stream_handler.setFormatter(formatter)
    fh_db.setFormatter(formatter)

    logger_database.addHandler(fh_db)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    return (log_file_path, log_file_database_path)
