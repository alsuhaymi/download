from utils.mail import send_mail
from utils.singleton import Singleton
