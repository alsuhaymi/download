import os

import cdsw
from pyspark.sql import SparkSession

from utils import Singleton

# os.environ["PYSPARK_PYTHON"] = (
#     "/opt/cloudera/parcels/ANACONDA_PYTHON/envs/3.6/bin/python"
# )

# app_name = cdsw.get_base_url().split("/")[-2]
app_name = os.getenv("CDSW_PROJECT")


class Spark(metaclass=Singleton):
    """
    Usage :
        spark = Spark()
        or
        new_config = {"my_param":"value"}
        spark = Spark(**new_config)
    """

    DEFAULT_CONFIG = {
        "spark.dynamicAllocation.maxExecutors": "50",
        "spark.dynamicAllocation.executorIdleTimeout": "60s",
        "spark.executor.heartbeatInterval": "30s",
        "spark.network.timeout": "12h",
        "spark.yarn.access.hadoopFileSystems": os.environ.get("STORAGE", "hdfs://advancedai/user/" + os.environ["HADOOP_USER_NAME"]),
        "spark.sql.autoBroadcastJoinThreshold": "-1",
        "spark.driver.memory": "512m",
    }

    def __init__(self, **kwargs):
        #spark = SparkSession.builder.master("yarn").appName(app_name)
        spark = SparkSession.builder.master("yarn").enableHiveSupport().appName(app_name)
        config = {**self.DEFAULT_CONFIG, **kwargs}
        for key, value in config.items():
            spark = spark.config(key, value)
        self._spark = spark.getOrCreate()

    def __getattr__(self, attr):
        """
        When we access an attribute or method we want to get the
        attribute/method of the spark object.

        Args:
            attr (str): Name of the attribute

        Returns:
            Attribute "attr" of the _spark object
        """
        return getattr(self._spark, attr)
