import datetime
import logging
import os
import sys
import time
from logging.handlers import TimedRotatingFileHandler


def create_logger(log_path=os.getcwd() + "/logs"):
    # Create a custom logger

    isExist = os.path.exists(log_path)
    if not isExist:
        # Create a new directory because it does not exist
        os.makedirs(log_path)

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    # Create handlers

    h_handler = TimedRotatingFileHandler(
        log_path + "/Log_out", when="midnight", utc=False
    )  # , when='D', interval=1)
    h_handler.suffix = "%Y%m%d.log"
    # h_handler.suffix = "%y%m%d_%H%M%S.log"
    h_handler.setLevel(logging.INFO)

    # Create formatters and add it to handlers
    # h_format = logging.Formatter('[%(asctime)s] - %(filename)s - {Mod :  %(module)s} - {FunName : %(funcName)s}- {MSECS : %(msecs)d} - {PID : %(process)d}  - {Line# : %(lineno)d} - %(levelname)s - %(message)s', '%m-%d %H:%M:%S')
    h_format = logging.Formatter(
        "[%(asctime)s] - %(filename)s - {Mod :  %(module)s} - {FunName : %(funcName)s}- {PID : %(process)d}  - {Line# : %(lineno)d} - %(levelname)s - %(message)s",
        "%m-%d %H:%M:%S",
    )
    h_handler.setFormatter(h_format)
    # Add handlers to the logger
    logger.addHandler(h_handler)
    return logger


if __name__ == "__main__":
    pass

    # logging=create_logger()
