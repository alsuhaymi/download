"""
Utility module to send mail notifications

Can send mails in text or html format with or without attachement

Needs this SMTP  parameters  :

smtp_host : SMTP Server host , for sgbdf  use smtp.mail.saint-gobain.net
smtp_port : SMTP Server port , for sgbdf use 25

See send_mail function documentation for full parameters

"""

import logging
import mimetypes
import os
import smtplib
from email.message import EmailMessage


def send_mail(
    smtp_host,
    smtp_port,
    smtp_from,
    smtp_to,
    content,
    subject,
    smtp_cc=None,
    attachment=None,
    is_html=False,
):
    """Send mail

    Args:
        smtp_host (string): SMTP Server host
        smtp_port (string): SMTP Server port
        smtp_from (string): Mail adress of ail sender
        smtp_to (string): Mail of destination , can contain multiple destination separated with comma (,)
        content (str): body of the mail to send , can be in html format in this case should set is_html to True
        subject (str): subject of the mail
        attachment (list(string) or string, optional): path of the attachment if any. Defaults to None.
        is_html (bool, optional): indicate if body is in html format. Defaults to False.
    """

    msg = EmailMessage()
    if is_html:
        msg.set_content(content, subtype="html")
    else:
        msg.set_content(content)

    msg["Subject"] = subject

    msg["From"] = smtp_from
    msg["To"] = smtp_to
    if smtp_cc:
        msg["Cc"] = smtp_cc

    if attachment:
        if isinstance(attachment, str):
            attachment = [attachment]

        for file_path in attachment:
            ctype, encoding = mimetypes.guess_type(file_path)
            if ctype is None or encoding is not None:
                # No guess could be made, or the file is encoded (compressed), so
                # use a generic bag-of-bits type.
                ctype = "application/octet-stream"

            maintype, subtype = ctype.split("/", 1)
            with open(file_path, "rb") as in_file:
                msg.add_attachment(
                    in_file.read(),
                    maintype=maintype,
                    subtype=subtype,
                    filename=os.path.basename(file_path),
                )

    smtp_server = smtplib.SMTP(smtp_host, smtp_port)

    logging.info("sending mail to {}".format(msg["To"]))
    try:
        send_result = smtp_server.send_message(msg)
    except Exception as exception:
        logging.error("Error while sending mail : {}".format(exception))
    else:
        if send_result != {}:
            logging.error(
                "Error while sending mail to this recipients: {}".format(send_result)
            )
        else:
            logging.info("sending mail to {} succeeded".format(msg["To"]))
    finally:
        smtp_server.quit()
