import csv
import logging
import os
import subprocess
import sys

# import jaydebeapi
import pandas as pd
import teradatasql as td
from impala.dbapi import connect
from pyspark.sql.types import *
from pyspark.sql.utils import AnalysisException

from settings import settings
from utils import hdfs_tools
from utils.spark import Spark

import numpy as np
np.bool = np.bool_

# TD_DB_HOST = os.environ.get('TD_DB_HOST')
# TD_DB_USERNAME = os.environ.get('TD_DB_USERNAME')
# TD_DB_PASSWORD = os.environ.get('TD_DB_PASSWORD')

# HIVE_DB_USERNAME = os.environ.get("HIVE_DB_USERNAME")
# HIVE_DB_PASSWORD = os.environ.get('HIVE_DB_PASSWORD')

TD_DB_HOST = settings.teradata_host
TD_DB_USERNAME = settings.teradata_username
TD_DB_PASSWORD = settings.teradata_password

# HIVE_DB_USERNAME = settings.hive_username
# HIVE_DB_PASSWORD = settings.hive_password
# HIVE_HOST = settings.hive_host
# HIVE_DB_SCHEMA = settings.hive_db_schema

HDFS_FOLDER = settings.hdfs_folder


def run_cmd(cmd, raise_err=True):
    """
    Run Linux commands using Python's subprocess module
    Args:
        cmd (str) - Linux command to run
    Returns:
        process
    """
    print("Running system command: {0}".format(cmd))
    proc = subprocess.run(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    if proc.returncode != 0 and raise_err == True:
        raise RuntimeError(
            "Error running command: {}. Return code: {}, Output: {}, Error: {}".format(
                cmd, proc.returncode, proc.stdout, proc.stderr
            )
        )
    return proc


def create_teradata_connection(
    dns_name: str = TD_DB_HOST,
    username: str = TD_DB_USERNAME,
    password: str = TD_DB_PASSWORD,
) -> td.connect:
    """
    This function aims to create teradata connection.

    Args:
        logging:(logger) instance of the logging object, where to log
        dns_name:(str)
        username:(str)
        password:(str)
    Return:
        connection: teradata.connection connection object
    """
    try:

        connection = td.connect(None, host=dns_name, user=username, password=password)
        logging.info("SUCCESSFULLY connected to teradata")
        return connection
    except Exception as err:
        logging.error(f"connection to teradata FAILED, the error: {err}")
        sys.exit(1)


# def hive_connection(
#     HIVE_DB_USERNAME: str = HIVE_DB_USERNAME, HIVE_DB_PASSOWRD: str = HIVE_DB_PASSWORD
# ):

#     import os

#     import jpype

#     driver_jar_path = "HiveJDBC41.jar"
#     os.environ["CLASSPATH"] = driver_jar_path
#     hive_conn = jaydebeapi.connect(
#         jclassname="com.cloudera.hive.jdbc41.HS2Driver",
#         url=f"jdbc:hive2://{HIVE_HOST}/default;transportMode=http;httpPath=cliservice;socketTimeout=60;ssl=1;retries=3;",
#         driver_args=[HIVE_DB_USERNAME, HIVE_DB_PASSWORD],
#     )

#     return hive_conn


def spark_connection(**configs):
    spark_conn = Spark(**configs)
    return spark_conn


def insert_data_hive(table_name, df):
    try:
        import datetime
        import sys

        data_path = settings.data_path

        # Create a data folder if it is doesnot exists
        isExist = os.path.exists(data_path)
        logging.info(f"[debug] - does file {data_path} exists: {isExist}")
        if not isExist:
            # Create a new directory because it does not exist
            os.makedirs(data_path)
        file_name = (
            table_name.replace(".", "_")
            + datetime.datetime.now().strftime("%d%m%Y")
            + ".csv"
        )
        local_file = data_path + "/" + file_name
        logging.info(f"[debug] - rewriting df of type {type(df)} into {local_file} exists")
        df.to_csv(f"{local_file}")
        # os.system(f"bash beeline_command.sh {file_path} {file_name} {table_name}")
        logging.info(f"[debug] - running ingestion args file_path: {local_file}")
        logging.info(f"[debug] - running ingestion args file_name: {file_name}") 
        logging.info(f"[debug] - running ingestion args table_name: {table_name}") 
        logging.info(f"[debug] - running ingestion args HDFS_FOLDER: {HDFS_FOLDER}") 

        run_ingestion_in_hive(local_file, file_name, table_name, HDFS_FOLDER)
    except Exception as err:
        logging.error(f"inserting csv to teradata FAILED, the error: {err}")
        sys.exit(1)


def run_ingestion_in_hive(
    file_path: str, file_name: str, table_name: str, hdfs_folder: str
):
    try:
        # encoding = sys.getdefaultencoding()

        # cmd = (
        #     "hdfs dfs -ls 2>>/dev/null | awk -v folder={HDFS_FOLDER} '$8 == folder "
        #     + str("{")
        #     + "print $8"
        #     + str("}")
        #     +"'"
        # )
        # folder = run_cmd(cmd)

        # folder = folder.stdout.decode(encoding).strip("\n")
        db_name = table_name.split(".")[0]
        table_name = table_name.split(".")[1]

        # hdfs_path = os.path.join(
        #     "hdfs://advancedai",
        #     settings.storage.format(user=os.getenv("HADOOP_USER_NAME")),
        #     hdfs_folder
        # )
        user_name = settings.storage.format(user=os.getenv("HADOOP_USER_NAME"))
        hdfs_path = f"hdfs://advancedai/{user_name}/{hdfs_folder}" 
        logging.info(f"Checking the presence of folder in HDFS {hdfs_path}")

        if not hdfs_tools.hdfs_test(hdfs_path, "-d"):
            print(" Folder does not exist in HDFS, so creating folder in HDFS ")
            hdfs_tools.hdfs_mkdir(hdfs_path, True)

        logging.info("Uploading the file to HDFS and inserting into Hive table")
        logging.info(f"[DEBUG] current hdfs path: {hdfs_path}")
        logging.info(f"[DEBUG] local file path: {file_path}")
        hdfs_tools.hdfs_put(file_path, hdfs_path, force=True)

        spark_conn = spark_connection()

        # Load data from HDFS into the Hive table
        tafani_data = spark_conn.read.csv(
            os.path.join(hdfs_path, file_name), header=True, inferSchema=True
        )

        # ...and inspect the data.
        tafani_data.show()

        tafani_data.printSchema()

        spark_conn.sql("show databases").show()

        if db_name not in list(
            spark_conn.sql("show databases").toPandas()["namespace"]
        ):
            print("creating the " + db_name + " database")
            try:
                spark_conn.sql(f"CREATE DATABASE {db_name}")
            except AnalysisException as ae:
                print(ae)

        spark_conn.sql(f"show tables in {db_name}").show()

        if table_name not in list(
            spark_conn.sql(f"show tables in {db_name}").toPandas()["tableName"]
        ):
            print("creating the " + table_name + " table")

            try:
                tafani_data.write.format("parquet").mode("overwrite").saveAsTable(
                    f"{db_name}.{table_name}"
                )
            except AnalysisException as ae:
                print(ae)
                print("Removing the conflicting directory from storage location.")

                conflict_location = f"{settings.storage}/datalake/data/warehouse/tablespace/external/hive/{table_name}"
                cmd = ["hdfs", "dfs", "-rm", "-r", conflict_location]
                subprocess.call(cmd)
                tafani_data.write.format("parquet").mode("overwrite").saveAsTable(
                    f"{db_name}.{table_name}"
                )
            # Show the data in the hive table
            spark_conn.sql(f"select * from {db_name}.{table_name}").show()

            # To get more detailed information about the hive table you can run this:
            spark_conn.sql(f"describe formatted {db_name}.{table_name}").toPandas()
    except RuntimeError as error:
        print(
            "Could not interact with external data store so local project storage will be used. HDFS DFS command failed with the following error:"
        )
        print(error)


def insert_csv_into_teradata(
    conn: td.connect, schema: str, table: str, csv_file_path: str
) -> None:
    """
    This function aims to insert a csv data into a table in teradata

    Args:
        conn: (td.connection),connection instance to teradata
        schema : str, schema that will be used
        table: str,
        sql_file_path:(str),the query to be executed
        csv_file_path:(str),the csv path location it should be the absolute path with the extention ex. folder/floder/dataPy.csv
        logging:(logger),instance of logging object, where to log
    Return:
        df:(pandas dataframe)

    """
    try:
        logging.info("reading csv file as dataframe...")
        df = pd.read_csv(csv_file_path)
        logging.info("SUCCESSFULLY read csv file into dataframe")
        columns = df.columns
        columns_length = len(columns)
        if columns_length == 0:
            raise Exception("CSV file doesn't has any columns")
        elif columns_length == 1:
            attributes = "?"
        else:
            attributes = (columns_length - 1) * "?, "
            attributes = attributes + "?"
        logging.info("writing csv in teradata...")
        with open(csv_file_path, newline="") as f:
            with conn.cursor() as cur:
                cur.execute(
                    f"insert into {schema}.{table} ({attributes})",
                    [row for row in csv.reader(f)],
                )
        logging.info("SUCCESSFULLY wrote the csv in teradata")
    except Exception as err:
        logging.error(f"inserting csv to teradata FAILED, the error: {err}")
        sys.exit(1)


def send_error_email_using_other_machine(
    msg: str,
    to_email: str,
    cc_email: str,
    subject: str = "error",
    prefix: str = "Error_",
) -> None:
    """
    This function aims to send email when an error arises

    Args:
        logging:(logger), instance of logging object, where to log
        msg: (str) the msg of the email
        to_email:(str)
        cc_email:(str)
        subject: (str) the subject of the email, predefined value='error'
        prefix: (str) the subject of the prefix, predefined value="Error_"
    Return:
        none
    """
    try:

        sub = prefix + subject
        logging.info(
            f"At {send_error_email_using_other_machine.__module__}->{send_error_email_using_other_machine.__name__}, sending error email..."
        )
        os.system(
            '" echo -e "" '
            + msg
            + '"" | mutt  -s "" '
            + sub
            + '"" -c '
            + cc_email
            + " -- "
            + to_email
            + '"'
        )
        logging.info(
            f"At {send_error_email_using_other_machine.__module__}->{send_error_email_using_other_machine.__name__}, SUCCESSFULLY sent the error email"
        )
    except Exception as err:
        logging.error(
            f"At {send_error_email_using_other_machine.__module__}->{send_error_email_using_other_machine.__name__}, FAILED in checking/creating directory, the error: {err}, the function signture: {send_error_email_using_other_machine.__doc__}"
        )
        sys.exit(1)


def send_success_email(
    msg: str,
    to_email: str,
    cc_email: str,
    subject: str = "Success",
    prefix: str = "Success_",
) -> None:
    """
    This function aims to send email of a successful run

    Args:
        logging:(logger), instance of logging object, where to log
        msg: (str) the msg of the email
        to_email:(str)
        cc_email:(str)
        subject: (str) the subject of the email, predefined value='error'
        prefix: (str) the subject of the prefix, predefined value="Error_"
    Return:
        none
    """
    try:

        sub = prefix + subject
        logging.info(
            f"At {send_success_email.__module__}->{send_success_email.__name__}, sending success email..."
        )
        os.system(
            '" echo -e "" '
            + msg
            + '"" | mutt  -s "" '
            + sub
            + '"" -c '
            + cc_email
            + " -- "
            + to_email
            + '"'
        )
        logging.info(
            f"At {send_success_email.__module__}->{send_success_email.__name__}, SUCCESSFULLY sent the success email"
        )
    except Exception as err:
        logging.error(
            f"At {send_success_email.__module__}->{send_success_email.__name__}, FAILED in sending success email, the error: {err}, the function signture: {send_success_email.__doc__}"
        )
        sys.exit(1)
