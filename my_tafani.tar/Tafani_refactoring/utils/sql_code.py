import csv
import logging
import os
import sys

import pandas as pd
import teradatasql as td

import utils.mle_utils as mle_utils
from settings import settings

# TD_DB_SCHEMA=os.environ.get("TD_DB_SCHEMA")
# HIVE_DB_SCHEMA=os.environ.get("HIVE_DB_SCHEMA")

TD_DB_SCHEMA_SOURCE = settings.teradata_db_schema_source
# TD_TABLE_SOURCE = settings.teradata_table_source
TD_DB_SCHEMA_TARGET = settings.teradata_db_schema_target
TD_TABLE_TARGET = settings.teradata_table_target

HIVE_DB_SCHEMA = settings.hive_db_schema


def save_model_results_TD(td_conn: td.connect) -> None:
    """
    This function aims to save the model reults

    Args:
        conn: (td.connection),connection instance to teradata

        logging:(logger),instance of logging object, where to log
    Return:
        df:(pandas dataframe)

    """
    try:
        # TD_DB_SCHEMA=os.environ.get("TD_DB_SCHEMA")

        logging.info("saving model data results to TD tabel")
        df = pd.read_csv(os.path.join(settings.data_path, settings.output_final_file))
        df["QUESTION_ID"] = df["QUESTION_ID"].astype(str)
        cur = td_conn.cursor()
        # stmt=f"insert into {TD_DB_SCHEMA_TARGET}.TAFANI_Analytics (?, ?, ?, ?, ?)"
        # table=f"{TD_DB_SCHEMA}.TAFANI_Analytics "
        stmt = f"insert into {TD_DB_SCHEMA_TARGET}.{TD_TABLE_TARGET} (?, ?, ?, ?, ?)"
        table = f"{TD_DB_SCHEMA}.{TD_TABLE_TARGET} "
        for index, row in df.iterrows():
            cur.execute(stmt, row.to_list())

        logging.info("SUCCESSFULLY finished saving the data")

    except Exception as err:
        logging.error(f"at saveing the model results{err}")
        sys.exit(1)


# def excute_before_model(td_conn: td.connect, hive_conn, logging) -> None:
#     """
#     This function aims to excute list of sql queries

#     Args:
#         conn: (td.connection),connection instance to teradata

#         logging:(logger),instance of logging object, where to log
#     Return:
#         df:(pandas dataframe)

#     """
#     try:
#         logging.info("entered sql queries fun 1")
#         hive_cursor = hive_conn.cursor()

#         # getting data from TD view and insert into hive table

#         logging.info("At  executing the query 1...")
#         hive_del_TAFANI_Question_CML = f"Truncate table {HIVE_DB_SCHEMA}.{HIVE_TABLE}"
#         hive_cursor.execute(hive_del_TAFANI_Question_CML)

#         logging.info("At  executing the query 2...")
#         # stmt_td_df_general_questions_v_vw="SELECT * FROM Dp_tafani_vw.general_questions_v_vw@STC3TD2HDP5_CADATeam"
#         stmt_td_df_general_questions_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.general_questions_v_vw@STC3TD2HDP5_CADATeam"
#         td_df_general_questions_v_vw = pd.read_sql(
#             stmt_td_df_general_questions_v_vw, td_conn
#         )
#         logging.info("At  executing the query 3...")
#         td_df_general_questions_v_vw = td_df_general_questions_v_vw.fillna(0)

#         td_df_general_questions_v_vw["role_id"] = (
#             td_df_general_questions_v_vw["role_id"].fillna(0).astype(int)
#         )
#         td_df_general_questions_v_vw["category_id"] = (
#             td_df_general_questions_v_vw["category_id"].fillna(0).astype(int)
#         )
#         td_df_general_questions_v_vw["sub_category_id"] = (
#             td_df_general_questions_v_vw["sub_category_id"].fillna(0).astype(int)
#         )
#         td_df_general_questions_v_vw["level3_sub_category_id"] = (
#             td_df_general_questions_v_vw["level3_sub_category_id"].fillna(0).astype(int)
#         )
#         td_df_general_questions_v_vw["level4_sub_category_id"] = (
#             td_df_general_questions_v_vw["level4_sub_category_id"].fillna(0).astype(int)
#         )
#         td_df_general_questions_v_vw["user_id"] = (
#             td_df_general_questions_v_vw["user_id"].fillna(0).astype(int)
#         )
#         td_df_general_questions_v_vw["question_id"] = (
#             td_df_general_questions_v_vw["question_id"].fillna(0).astype(int)
#         )

#         table_name = f"{HIVE_DB_SCHEMA}.{HIVE_TABLE}"
#         mle_utils.insert_data_hive(table_name, td_df_general_questions_v_vw)
#         logging.info("SUCCESSFULLY finished sql excute_before_model queries")
#         hive_conn.close()
#         td_conn.close()

#     except Exception as err:
#         logging.error(f"at excute before the model: {err}")
#         sys.exit(1)


def excute_before_model(td_conn: td.connect, spark_conn) -> None:
    """
    This function aims to excute list of sql queries

    Args:
        conn: (td.connection),connection instance to teradata

        logging:(logger),instance of logging object, where to log
    Return:
        df:(pandas dataframe)

    """
    try:
        logging.info("entered sql queries fun 1")

        # getting data from TD view and insert into hive table

        logging.info("At  executing the query 1...")
        hive_del_TAFANI_Question_CML = (
            f"Truncate table {HIVE_DB_SCHEMA}.TAFANI_Question_CML_nacid"
        )
        spark_conn.sql(hive_del_TAFANI_Question_CML)

        logging.info("At  executing the query 2...")
        # stmt_td_df_general_questions_v_vw="SELECT * FROM Dp_tafani_vw.general_questions_v_vw@STC3TD2HDP5_CADATeam"
        stmt_td_df_general_questions_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.general_questions_v_vw@STC3TD2HDP5_CADATeam"
        td_df_general_questions_v_vw = pd.read_sql(
            stmt_td_df_general_questions_v_vw, td_conn
        )
        logging.info("At  executing the query 3...")
        td_df_general_questions_v_vw = td_df_general_questions_v_vw.fillna(0)

        td_df_general_questions_v_vw["role_id"] = (
            td_df_general_questions_v_vw["role_id"].fillna(0).astype(int)
        )
        td_df_general_questions_v_vw["category_id"] = (
            td_df_general_questions_v_vw["category_id"].fillna(0).astype(int)
        )
        td_df_general_questions_v_vw["sub_category_id"] = (
            td_df_general_questions_v_vw["sub_category_id"].fillna(0).astype(int)
        )
        td_df_general_questions_v_vw["level3_sub_category_id"] = (
            td_df_general_questions_v_vw["level3_sub_category_id"].fillna(0).astype(int)
        )
        td_df_general_questions_v_vw["level4_sub_category_id"] = (
            td_df_general_questions_v_vw["level4_sub_category_id"].fillna(0).astype(int)
        )
        td_df_general_questions_v_vw["user_id"] = (
            td_df_general_questions_v_vw["user_id"].fillna(0).astype(int)
        )
        td_df_general_questions_v_vw["question_id"] = (
            td_df_general_questions_v_vw["question_id"].fillna(0).astype(int)
        )

        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Question_CML"
        mle_utils.insert_data_hive(table_name, td_df_general_questions_v_vw)
        logging.info("SUCCESSFULLY finished sql excute_before_model queries")
        td_conn.close()

    except Exception as err:
        logging.error(f"at excute before the model: {err}")
        sys.exit(1)


# def excute_after_model(td_conn: td.connect, hive_conn, logging) -> None:
#     """
#     This function aims to excute list of sql queries

#     Args:
#         conn: (td.connection),connection instance to teradata

#         logging:(logger),instance of logging object, where to log
#     Return:
#         df:(pandas dataframe)

#     """
#     try:

#         logging.info("entered sql queries fun 1")

#         hive_cursor = hive_conn.cursor()

#         logging.info("At  executing the query 1...")
#         hive_del_TAFANI_Analytics_RESULTS_CML = (
#             f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_Analytics_RESULTS_CML"
#         )
#         hive_cursor.execute(hive_del_TAFANI_Analytics_RESULTS_CML)

#         logging.info("At  executing the query 2...")
#         hive_del_TAFANI_Answers_CML = (
#             f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_Answers_CML"
#         )
#         hive_cursor.execute(hive_del_TAFANI_Answers_CML)

#         logging.info("At  executing the query 3..")
#         hive_del_TAFANI_QAL_CML = f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_QAL_CML"
#         hive_cursor.execute(hive_del_TAFANI_QAL_CML)

#         logging.info("At  executing the query 4..")
#         hive_del_TAFANI_VOE_CML = f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_VOE_CML"
#         hive_cursor.execute(hive_del_TAFANI_VOE_CML)

#         logging.info("At  executing the query 5..")
#         hive_del_TAFANI_MEMBERS_CML = (
#             f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_MEMBERS_CML"
#         )
#         hive_cursor.execute(hive_del_TAFANI_MEMBERS_CML)

#         logging.info("At  executing the query 6..")
#         hive_del_TAFANI_Customers_CML = (
#             f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_Customers_CML"
#         )
#         hive_cursor.execute(hive_del_TAFANI_Customers_CML)

#         logging.info("At  executing the query 7..")
#         stmt_td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML = f"SELECT TA.*, TQ.USER_ID FROM {HIVE_DB_SCHEMA}.TAFANI_Analytics TA LEFT JOIN {HIVE_DB_SCHEMA}.TAFANI_QUESTION TQ ON TA.QUESTION_ID = TQ.QUESTION_ID "
#         td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML = pd.read_sql(
#             stmt_td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML, td_conn
#         )
#         td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML = (
#             td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML.fillna(0)
#         )

#         logging.info("At  executing the query 8..")
#         stmt_td_df_general_answer_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.general_answer_v_vw@STC3TD2HDP5_CADATeam"
#         td_df_general_answer_v_vw = pd.read_sql(stmt_td_df_general_answer_v_vw, td_conn)
#         td_df_general_answer_v_vw = td_df_general_answer_v_vw.fillna(0)

#         logging.info("At  executing the query 9..")
#         stmt_td_df_question_answer_likes_details_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.question_answer_likes_details_v_vw@STC3TD2HDP5_CADATeam"
#         td_df_question_answer_likes_details_v_vw = pd.read_sql(
#             stmt_td_df_question_answer_likes_details_v_vw, td_conn
#         )
#         td_df_question_answer_likes_details_v_vw = (
#             td_df_question_answer_likes_details_v_vw.fillna(0)
#         )

#         logging.info("At  executing the query 10.")
#         stmt_td_df_voe_in_feedbacks_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.voe_in_feedbacks_v_vw@STC3TD2HDP5_CADATeam"
#         td_df_voe_in_feedbacks_v_vw = pd.read_sql(
#             stmt_td_df_voe_in_feedbacks_v_vw, td_conn
#         )
#         td_df_voe_in_feedbacks_v_vw = td_df_voe_in_feedbacks_v_vw.fillna(0)

#         logging.info("At  executing the query 11..")
#         stmt_td_df_tafani_members_v_vw = """
#                         SELECT
#                             tafani_memebr_id
#                             ,member_name_ar
#                             ,memeber_name_en
#                             ,creation_date
#                             ,joining_date
#                             ,status_name_ar
#                             ,status_name_en
#                             ,email
#                             ,mobile_number
#                             ,removal_quit_date
#                             ,roles
#                             ,"title"
#                             ,employee_department
#                             ,last_login_date
#                             ,last_login_time
#                             ,number_of_customers
#                             ,number_of_opened_enquiries
#                             ,number_of_closed_enquiries
#                             ,number_of_asked_questions
#                             ,number_of_answers
#                             ,number_of_likes
#                             ,number_of_dislikes
#                             ,number_of_recieved_likes
#                             ,number_of_recieved_dislikes
#                             ,number_of_pending_invitations
#                             ,number_of_active_customers
#                             ,total_logins
#                             ,number_of_broadcast_msgs
#                             ,number_of_comments
#                             ,bd_insertion_time
#                             ,number_of_asked_questions+number_of_answers+number_of_likes+number_of_active_customers as total_engagement
#                         	,obsdate
#                         		,CASE when total_engagement >0 and total_engagement<51 then 'Low'
#                         			  when total_engagement >50 and total_engagement<301 then 'Medium'
#                         			  when total_engagement >300 then 'High' ELSE 0 END as Rank_
#                         FROM Dp_tafani_vw.tafani_members_v_vw@STC3TD2HDP5_CADATeam
#                         where status_name_en='Activated' and roles IN ('tafani MemberInternal Customer','tafani Member')
#                         """
#         td_df_tafani_members_v_vw = pd.read_sql(stmt_td_df_tafani_members_v_vw, td_conn)
#         td_df_tafani_members_v_vw = td_df_tafani_members_v_vw.fillna(0)

#         logging.info("At  executing the query 12.")
#         stmt_td_df_tafani_customers_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.tafani_customers_v_vw@STC3TD2HDP5_CADATeam"
#         td_df_tafani_customers_v_vw = pd.read_sql(
#             stmt_td_df_tafani_customers_v_vw, td_conn
#         )
#         td_df_tafani_customers_v_vw = td_df_tafani_customers_v_vw.fillna(0)

#         logging.info("At  executing the query 13")
#         table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Analytics_RESULTS_CML"
#         mle_utils.insert_data_hive(
#             table_name, td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML
#         )

#         logging.info("At  executing the query 14")
#         table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Answers_CML"
#         mle_utils.insert_data_hive(table_name, td_df_general_answer_v_vw)

#         logging.info("At  executing the query 15")
#         table_name = f"{HIVE_DB_SCHEMA}.TAFANI_QAL_CML"
#         mle_utils.insert_data_hive(table_name, td_df_question_answer_likes_details_v_vw)

#         logging.info("At  executing the query 16")
#         table_name = f"{HIVE_DB_SCHEMA}.TAFANI_VOE_CML"
#         mle_utils.insert_data_hive(table_name, td_df_voe_in_feedbacks_v_vw)

#         logging.info("At  executing the query 17")
#         table_name = f"{HIVE_DB_SCHEMA}.TAFANI_MEMBERS_CML"
#         mle_utils.insert_data_hive(table_name, td_df_tafani_members_v_vw)

#         logging.info("At  executing the query 18")
#         table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Customers_CML"
#         mle_utils.insert_data_hive(table_name, td_df_tafani_customers_v_vw)

#         hive_conn.close()
#         td_conn.close()

#     except Exception as err:
#         logging.error(f" at execute after the model failed: {err}")
#         sys.exit(1)


def excute_after_model(td_conn: td.connect, spark_conn) -> None:
    """
    This function aims to excute list of sql queries

    Args:
        conn: (td.connection),connection instance to teradata

        logging:(logger),instance of logging object, where to log
    Return:
        df:(pandas dataframe)

    """
    try:

        logging.info("entered sql queries fun 1")

        logging.info("At  executing the query 1...")
        hive_del_TAFANI_Analytics_RESULTS_CML = (
            f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_Analytics_RESULTS_CML"
        )
        spark_conn.sql(hive_del_TAFANI_Analytics_RESULTS_CML)

        logging.info("At  executing the query 2...")
        hive_del_TAFANI_Answers_CML = (
            f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_Answers_CML"
        )
        spark_conn.sql(hive_del_TAFANI_Answers_CML)

        logging.info("At  executing the query 3..")
        hive_del_TAFANI_QAL_CML = f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_QAL_CML"
        spark_conn.sql(hive_del_TAFANI_QAL_CML)

        logging.info("At  executing the query 4..")
        hive_del_TAFANI_VOE_CML = f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_VOE_CML"
        spark_conn.sql(hive_del_TAFANI_VOE_CML)

        logging.info("At  executing the query 5..")
        hive_del_TAFANI_MEMBERS_CML = (
            f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_MEMBERS_CML"
        )
        spark_conn.sql(hive_del_TAFANI_MEMBERS_CML)

        logging.info("At  executing the query 6..")
        hive_del_TAFANI_Customers_CML = (
            f"Truncate table  {HIVE_DB_SCHEMA}.TAFANI_Customers_CML"
        )
        spark_conn.sql(hive_del_TAFANI_Customers_CML)

        logging.info("At  executing the query 7..")
        stmt_td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML = f"SELECT TA.*, TQ.USER_ID FROM {TD_DB_SCHEMA_SOURCE}.TAFANI_Analytics TA LEFT JOIN {HIVE_DB_SCHEMA}.TAFANI_QUESTION TQ ON TA.QUESTION_ID = TQ.QUESTION_ID "
        td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML = pd.read_sql(
            stmt_td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML, td_conn
        )
        td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML = (
            td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML.fillna(0)
        )

        logging.info("At  executing the query 8..")
        stmt_td_df_general_answer_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.general_answer_v_vw@STC3TD2HDP5_CADATeam"
        td_df_general_answer_v_vw = pd.read_sql(stmt_td_df_general_answer_v_vw, td_conn)
        td_df_general_answer_v_vw = td_df_general_answer_v_vw.fillna(0)

        logging.info("At  executing the query 9..")
        stmt_td_df_question_answer_likes_details_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.question_answer_likes_details_v_vw@STC3TD2HDP5_CADATeam"
        td_df_question_answer_likes_details_v_vw = pd.read_sql(
            stmt_td_df_question_answer_likes_details_v_vw, td_conn
        )
        td_df_question_answer_likes_details_v_vw = (
            td_df_question_answer_likes_details_v_vw.fillna(0)
        )

        logging.info("At  executing the query 10.")
        stmt_td_df_voe_in_feedbacks_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.voe_in_feedbacks_v_vw@STC3TD2HDP5_CADATeam"
        td_df_voe_in_feedbacks_v_vw = pd.read_sql(
            stmt_td_df_voe_in_feedbacks_v_vw, td_conn
        )
        td_df_voe_in_feedbacks_v_vw = td_df_voe_in_feedbacks_v_vw.fillna(0)

        logging.info("At  executing the query 11..")
        stmt_td_df_tafani_members_v_vw = f"""
                        SELECT
                            tafani_memebr_id             
                            ,member_name_ar               
                            ,memeber_name_en              
                            ,creation_date                
                            ,joining_date                 
                            ,status_name_ar               
                            ,status_name_en               
                            ,email                        
                            ,mobile_number                
                            ,removal_quit_date            
                            ,roles                        
                            ,"title"                        
                            ,employee_department          
                            ,last_login_date              
                            ,last_login_time              
                            ,number_of_customers          
                            ,number_of_opened_enquiries   
                            ,number_of_closed_enquiries   
                            ,number_of_asked_questions    
                            ,number_of_answers            
                            ,number_of_likes              
                            ,number_of_dislikes           
                            ,number_of_recieved_likes     
                            ,number_of_recieved_dislikes  
                            ,number_of_pending_invitations
                            ,number_of_active_customers   
                            ,total_logins                 
                            ,number_of_broadcast_msgs     
                            ,number_of_comments           
                            ,bd_insertion_time            
                            ,number_of_asked_questions+number_of_answers+number_of_likes+number_of_active_customers as total_engagement
                        	,obsdate   
                        		,CASE when total_engagement >0 and total_engagement<51 then 'Low'
                        			  when total_engagement >50 and total_engagement<301 then 'Medium'	
                        			  when total_engagement >300 then 'High' ELSE 0 END as Rank_
                        FROM {TD_DB_SCHEMA_SOURCE}.tafani_members_v_vw@STC3TD2HDP5_CADATeam
                        where status_name_en='Activated' and roles IN ('tafani MemberInternal Customer','tafani Member')
                        """
        td_df_tafani_members_v_vw = pd.read_sql(stmt_td_df_tafani_members_v_vw, td_conn)
        td_df_tafani_members_v_vw = td_df_tafani_members_v_vw.fillna(0)

        logging.info("At  executing the query 12.")
        stmt_td_df_tafani_customers_v_vw = f"SELECT * FROM {TD_DB_SCHEMA_SOURCE}.tafani_customers_v_vw@STC3TD2HDP5_CADATeam"
        td_df_tafani_customers_v_vw = pd.read_sql(
            stmt_td_df_tafani_customers_v_vw, td_conn
        )
        td_df_tafani_customers_v_vw = td_df_tafani_customers_v_vw.fillna(0)

        logging.info("At  executing the query 13")
        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Analytics_RESULTS_CML"
        mle_utils.insert_data_hive(
            table_name, td_df_TAFANI_Analytics_CML_TAFANI_QUESTION_CML
        )

        logging.info("At  executing the query 14")
        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Answers_CML"
        mle_utils.insert_data_hive(table_name, td_df_general_answer_v_vw)

        logging.info("At  executing the query 15")
        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_QAL_CML"
        mle_utils.insert_data_hive(table_name, td_df_question_answer_likes_details_v_vw)

        logging.info("At  executing the query 16")
        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_VOE_CML"
        mle_utils.insert_data_hive(table_name, td_df_voe_in_feedbacks_v_vw)

        logging.info("At  executing the query 17")
        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_MEMBERS_CML"
        mle_utils.insert_data_hive(table_name, td_df_tafani_members_v_vw)

        logging.info("At  executing the query 18")
        table_name = f"{HIVE_DB_SCHEMA}.TAFANI_Customers_CML"
        mle_utils.insert_data_hive(table_name, td_df_tafani_customers_v_vw)

        td_conn.close()

    except Exception as err:
        logging.error(f" at execute after the model failed: {err}")
        sys.exit(1)
