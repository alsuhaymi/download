from datetime import date

from settings.settings import Settings

# from utils.mail import send_mail
# from utils.singleton import Singleton

# settings = Settings()

# # Init settings from json file
# settings.load_from_json_file(
#     json_file="settings/example_settings.json",
#     make_checks=False,
#     make_actions=True,
# )
# error_dict = settings.make_checks()
# if error_dict:
#     raise Exception(f"errors on settings: {error_dict}")

# Init settings from json file
settings = Settings()
settings.load_from_json_file(
    "settings/general_settings.json",
    make_checks=False,
    make_actions=True,
)
error_dict = settings.make_checks()
if error_dict:
    raise Exception(f"errors on settings: {error_dict}")

settings.end_date = str(date.today())

__all__ = ["settings"]
