import logging
import os
import pathlib

from dateutil import parser

# Checks possible :
#     is_valid_path,
#     is_valid_path_editable,
#     is_valid_date,
#     is_in_possible_values,
#     is_valid_int,
#     is_valid_bool

# Action :
#     create_path_if_not_exist,
#     to_float,
#     to_int,
#     to_bool


def create_path_if_not_exists(i_value):
    """
    Create Path if not exists

    This function needs to return the value to be coherent with the convertion
    functions which returns a converted type of i_value
    """
    pathlib.Path(i_value.value).mkdir(parents=True, exist_ok=True)
    return i_value.value


def to_float(i_value):
    """
    Convert Value to Float
    """
    return float(i_value.value)


def to_int(i_value):
    """
    Convert Value to Int
    """
    return int(i_value.value)


def to_bool(i_value):
    """
    Convert Value to Boolean
    """
    out = True if (str(i_value.value).lower() == "true") else False

    # if str(i_value.value).lower() == "true":
    #     out = True
    # elif str(i_value.value).lower() == "false":
    #     out = False
    # else:
    #     out = None

    return out


def is_valid_path(i_value):
    """
    Check if the path exists
    """
    return pathlib.Path(i_value.value).exists()


def is_valid_path_editable(i_value):
    """
    Check if the path exists and is editable
    """
    return is_valid_path(i_value) and os.access(i_value.value, os.W_OK)


def is_valid_int(i_value):
    """
    Tests if the input is a valid int
    """
    if isinstance(i_value.value, int):
        out = True
    elif i_value.value.isdigit():
        out = True
    else:
        logging.error("{} is not a digit".format(i_value.value))
        out = False
    return out


def is_valid_bool(i_value):
    """
    Tests if the input is a valid Bool
    """
    if isinstance(i_value.value, bool):
        out = True
    elif i_value.value.lower() in ["true", "false"]:
        out = True
    else:
        logging.error("{} is not a boolean".format(i_value.value))
        out = False
    return out


def is_valid_date(i_value):
    """
    Tests if the input is a valid date format
    """
    try:
        parser.parse(i_value.value).date()
    except ValueError as value_error:
        logging.error(
            "date '{}' is not well formatted: {}".format(i_value.value, value_error)
        )
        return False
    else:
        return True


def is_in_possible_values(i_value):
    """
    Tests if value is in the liste of possible values
    """
    if not hasattr(i_value, "possible_values"):
        logging.error(
            "possible_values not defined for {} , return false ".format(i_value.value)
        )
        return False
    if i_value.value not in i_value.possible_values:
        logging.error(
            "value {} not in possible defined values : {}".format(
                i_value.value, ",".join(i_value.possible_values)
            )
        )
        return False
    return True


dict_action_function = {
    "create_path_if_not_exist": create_path_if_not_exists,
    "to_float": to_float,
    "to_int": to_int,
    "to_bool": to_bool,
}


dict_check_function = {
    "is_valid_path": is_valid_path,
    "is_valid_path_editable": is_valid_path_editable,
    "is_valid_date": is_valid_date,
    "is_in_possible_values": is_in_possible_values,
    "is_valid_int": is_valid_int,
    "is_valid_bool": is_valid_bool,
}


class SettingsValue:
    def __init__(self, name, json_value):
        self.name = name
        self.value = None

        if isinstance(json_value, dict):

            for key, value in json_value.items():
                setattr(self, key, value)

            if getattr(self, "required", None) is True:
                if (self.value is None) or (self.value == ""):
                    raise Exception(
                        "Value {} required  but not setted".format(self.name)
                    )

            if getattr(self, "environement", "") in os.environ:
                env = getattr(self, "environement")
                self.value = os.environ[env]
            elif hasattr(self, "default_value"):
                self.value = getattr(self, "default_value")

        else:
            self.value = json_value

    def __str__(self):
        return str(self.value)

    def __repr__(self):
        return repr(self.value)

    def make_checks(self):
        """
        Apply checks list as configured in json file
        return list epmty if all checks are ok else list of checks failed
        """
        checks_errors = []

        if hasattr(self, "checks"):
            for check in getattr(self, "checks"):
                if check not in dict_check_function:
                    checks_errors.append(check)
                elif not dict_check_function[check](self):
                    checks_errors.append(check)

        return checks_errors

    def make_actions(self):
        """
        Apply actions
        """
        if hasattr(self, "actions"):
            for action in getattr(self, "actions"):
                if action not in dict_action_function:
                    raise Exception("Action {} not implemented".format(action))

                self.value = dict_action_function[action](self)
