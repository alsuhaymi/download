"""
utility decorator, to make settings class iterable,
and, at the same time, be able to create a dict of settings with dict(settings)
"""


def iterable(cls):
    """Decorator to make settings class iterable"""

    def iterfn(self):
        """Iter function

        Yields:
            [Any]: attributes of object self
        """
        iters = dict(
            (key, value)
            for key, value in self.__dict__.items()
            if ((key[:1] != "_") and (not callable(getattr(self, key))))
        )
        iters2 = dict(
            (key, value.value)
            for key, value in self._dynamic_attributes.items()
            if ((key[:1] != "_") and (not callable(getattr(self, key))))
        )
        iters.update(iters2)

        for key, value in iters.items():
            yield key, value

    cls.__iter__ = iterfn
    return cls
