import importlib
import logging

from utils import Singleton

from .settings_iterable import iterable
from .settings_value import SettingsValue


@iterable
class Settings(metaclass=Singleton):
    _dynamic_attributes = {}

    def __init__(self):
        self._json_file = set()
        self._yaml_file = set()
        self._module_name = set()

    def _load_from(self, filepath, load_function, make_checks=True, make_actions=True):
        """Generic function to load settings from file

        Args:
            file ([type]): file to load
            load_function ([type]): load function
            make_checks (bool, optional): make checks. Defaults to True.
            make_actions (bool, optional): make actions. Defaults to True.
        """
        self._json_file.add(filepath)
        with open(filepath) as opened_file:
            config_dict = load_function(opened_file)
        self._load_from_config_dict(config_dict, make_checks, make_actions)

    def load_from_json_file(self, json_file, make_checks=True, make_actions=True):
        """
        Load settings from json file
        """
        from json import load

        self._load_from(json_file, load, make_checks, make_actions)

    def load_from_yaml_file(self, yaml_file, make_checks=True, make_actions=True):
        """Load settings from yaml file"""
        from yaml import load

        self._load_from(yaml_file, load, make_checks, make_actions)

    def _load_from_config_dict(self, config_dict, make_checks=True, make_actions=True):
        """
        Load settings from config_dict

        arguments :
          config_dict : dict type, dict containing params
          make_checks : bool type, when true make checks on settings loaded
          make_actions : bool type, when true execute actions - if any - loaded from config_dict

        return
          if make_checks is True return dictionnary of checks results
          else if make_checks is False return empty dict
        """

        for key, value in config_dict.items():
            self.__dict__.pop(key, None)
            settings_value = SettingsValue(key, value)
            self._dynamic_attributes[key] = settings_value

        if make_actions:
            self.make_actions()
        if make_checks:
            out = self.make_checks()
        else:
            out = {}
        return out

    def __setattr__(self, prop, val):
        self._dynamic_attributes.pop(prop, None)
        super().__setattr__(prop, val)

    def __getattr__(self, name):
        """
        Called when an attribute lookup has not found the attribute in the usual places
        name is the attribute name.
        return the (computed) attribute value or raise an AttributeError exception.
        """
        if name in self._dynamic_attributes:
            out = self._dynamic_attributes[name].value
        else:
            raise AttributeError(
                f"""Attribute  {name} not found, check settings file  """
            )
        return out

    def load_from_py_module(self, module):
        """
        Load settings from python module.
        The python module should contains values that will be added to the current object

        arguments :
            -module : string type , module name

        return False if execption while loading the module , True if module loading ok
        """

        try:
            mod = importlib.import_module(module)
        except Exception as exception:
            logging.error(f"Error while importing {module} : {exception}")
            return False
        for setting in dir(mod):
            if not (setting.startswith("__") or setting.startswith("_")):
                setting_value = getattr(mod, setting)
                setattr(self, setting, setting_value)

        return True

    def as_str(self):
        """
        Return formatted string of all string values
        """
        return "<Settings module : {} ,\nJSON Settings File : {} ,\nYAML Settings File : {} ,\nModule name : {},\nAttributes :\n\t{},\nJSON Attributes :\n\t{}>".format(
            self.__class__.__name__,
            ", ".join(self._json_file),
            ", ".join(self._yaml_file),
            ", ".join(self._module_name),
            "\n\t".join(
                "{}={!r}".format(k, v)
                for k, v in self.__dict__.items()
                if (not k[0] == "_")
            ),
            "\n\t".join(
                "{}={!r}".format(k, v)
                for k, v in self._dynamic_attributes.items()
                if (not k[0] == "_")
            ),
        )

    def __str__(self):
        """
        Called when calling str(Setting object)
        """
        return self.as_str()

    def __repr__(self):
        """
        called when calling repr(Setting object)
        """

        return self.as_str()

    def make_checks(self):
        """
        Apply all checks on values

        return dict value name -> List of dictionnary settings -> list of  checks error (only settings with errors are in the dict)
        """
        dict_value_checks_error = {}
        for value in self._dynamic_attributes.values():
            checks_list_result = value.make_checks()
            if checks_list_result:
                dict_value_checks_error[value.name] = checks_list_result

        return dict_value_checks_error

    def make_actions(self):
        """
        Make actions on values
        """
        for value in self._dynamic_attributes.values():
            value.make_actions()
