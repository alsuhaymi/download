import logging
import time

import utils.mle_utils as mle_utils
import utils.Python_notebooks_Tafani_Deployment as model
from settings import settings
from utils import send_mail
from utils.logging_setup import setup_logger


def run():
    start = time.monotonic()
    logging.info("Model running started")
    logging.info("Creating Hive connection for model function")
    # hive_conn = mle_utils.hive_connection()
    # model.run_model(hive_conn)
    spark_conn = mle_utils.spark_connection()
    model.run_model(spark_conn)
    end = time.monotonic()
    logging.info(f"Model running ended successfully in {end-start:.2f} seconds")
    return True, "Everything is ok !!"


if __name__ == "__main__":
    # setup logger
    log_file_path, log_file_database_path = setup_logger(
        "INFO", settings.log_dir, settings.log_file_name
    )
    status, message = run()
    # Mail Notification
    if settings.send_mail:
        send_mail(
            smtp_host=settings.smtp_host,
            smtp_port=settings.smtp_port,
            smtp_from=settings.smtp_from,
            smtp_to=settings.smtp_to,
            smtp_cc=settings.smtp_cc,
            content=message + "\nLog in attached file",
            subject=f"""Tafani - logs for model running job""",
            attachment=log_file_path,
        )
