# Tafani UC

MI Portal aims to detect, monitor, the customer experience and interaction on the forum with gamification analysis for the ambassadors users who are responsible to answer on the inquiries. The scope is to build topic extraction and sentiment analysis for the questions by using Arabic and English NLP for the questions.


## Features
Tafani UC offers the following features :
- A **Data Pipeline** which pulls data from Teradata, preprocess data (Removing punctuations, removing URLs, removing Stop words, lower casing, tokenization and stemming for the  questions to make the text ready for the TF and SA models) and apply the model to produce the desired outcomes that is saved into Teradata.
- A **ML model** which processes data and return back the results as follow:
    -	Topic extraction
    - Sentiment analysis

## Project Structure

The project is organized with the following folder structure:
```
.
├── settings/                    # settings file and script to set environment variables
├── utils/                       # Utilities used within the project
├── 0_install_dependencies.py    # python script to install python librairies
├── 1_data_ingest.py             # python script to ingest data into Hive
├── 2_model_run.py               # python script to run model and produce results
├── 3_model_postprocessing.py    # python script to postprocess results to get the desired outcomes
├── 4_model_result_saving.py     # python script save the desired outcomes in HDFS and Teradata
├── 5_clean_data.py              # python script to clean data stored locally during the previous steps 
├── README.md
└── requirements.txt
```
## Environment Variables
[Setting file](settings/general_settings.json) is located into [settings directory](settings). Below are description of settings needed to deploy model as a API endpoint.

|File|Name|Comment|Defaut Value|
|---|---|---|---|
|general_settings.json|HIVE_DB_SCHEMA|defining the schema of HIVE database|dp_cad_analytics|
|general_settings.json|TD_HOST|defining the Teradata hostname|default|
|general_settings.json|TD_USERNAME|defining the Teradata username|default|
|general_settings.json|TD_PASSWORD|defining the Teradata user password|default|
|general_settings.json|TD_DB_SCHEMA_SOURCE|defining the schema of Source Teradata database|Dp_tafani_vw|
|general_settings.json|TD_DB_SCHEMA_TARGET|defining the schema of Target Teradata database|Dp_tafani_vw|
|general_settings.json|TD_TABLE_TARGET|defining the name of Target Teradata table|TAFANI_Analytics|
|general_settings.json|HDFS_STORAGE|Hdfs storage root path|/user/{user}|
|general_settings.json|HDFS_FOLDER|Hdfs directory where will be stored results. Results will available into HDFS location `<HDFS_STORAGE>`/`<HDFS_FOLDER>`|tafani|
|general_settings.json|DATA_PATH|Local directory to save the results|output|
|general_settings.json|SEND_MAIL|Bool, send an alert email if True|False|
|general_settings.json|SMTP_TO|Email Address to send an alert email|aeldabe@stc.com.sa|
|general_settings.json|SMTP_CC|Email Address in copy to send an alert email|aeldabe@stc.com.sa|


Feel free either to modify directly the value of environment variables in this [Setting file](settings/general_settings.json) or set the value of environment variables into CML Model Deployment interface at project level by following instructions:
- In a CML workspace of project, navigate to `Project Settings`
- In the `Project Settings` windows, click on `Advanced`
- Set required environment variables as follows:
  - click on button `+` to add new environment variable
  - set the `Name` of the environment variable into the first column
  - set the `Value` of the environment variable into the second column
  - then click on `Submit` if all environment variables have been set. 

## How to run
### 0. Create project:
- In a CML workspace, click `New Project`, add a Project Name, select `git` as the Initial Setup option, select `HTTPS`, and copy in the field `Git URL of Project` the value `https://oauth2:<token>@gitlab.stc.com.sa/aeldabe/tafani.git` by replacing `<token>` by your gitlab access token. Then set `dev` as value of `Branch Name`.

Tafani UC will execute in `6 succesives jobs`:
1. [Install python librairies](#1-install-depencencies-job)
2. [Fetch data from Teradata and save them into Hive](#2-ingest-data-job)
3. [Run model and produce the results](#3-model-running-job)
4. [Postprocessing results and creating the desired outcomes](#4-model-postprocessing-job)
5. [Save the desired outcomes in HDFS and Teradata](#5-save-result-job)
6. [Cleaning local temp storage](#6-clean-data-job)

### 1. Install Depencencies Job
- Navigate to CML Job
- Click `New Job`
- Give it the Name `Install Depencencies` and Description
- Select Script `0_install_dependencies.py`
- Pick Runtime
  - Workbench -- Python 3.9 -- Standard -- 2024.08
- enable Spark
  - Spark 3.2.3 - CDP 7.1.7.2050
- Set Schedule 
  - either `Manual` for manual invocation
  - or `Recurring` for scheduled invocation
- Set Resource Profile
  - At least 2CPU / 4MEM
- Click `Create` to create the Job

### 2. Ingest Data Job
- Navigate to CML Job
- Click `New Job`
- Give it the Name `Ingest Data` and Description
- Select Script `1_data_ingest.py`
- Pick Runtime
  - Workbench -- Python 3.9 -- Standard -- 2024.08
- enable Spark
  - Spark 3.2.3 - CDP 7.1.7.2050
- Set Schedule at `Dependent` and than choose  `Install Depencencies`
- Set Resource Profile
  - At least 2CPU / 4MEM
- Click `Create` to create the Job

### 3. Model Running Job
- Navigate to CML Job
- Click `New Job`
- Give it the Name `Model Running` and Description
- Select Script `2_model_run.py`
- Pick Runtime
  - Workbench -- Python 3.9 -- Standard -- 2024.08
- enable Spark
  - Spark 3.2.3 - CDP 7.1.7.2050
- Set Schedule at `Dependent` and than choose  `Ingest Data`
- Set Resource Profile
  - At least 2CPU / 4MEM
- Click `Create` to create the Job

### 4. Model Postprocessing Job
- Navigate to CML Job
- Click `New Job`
- Give it the Name `Model Postprocessing` and Description
- Select Script `3_model_postprocessing.py`
- Pick Runtime
  - Workbench -- Python 3.9 -- Standard -- 2024.08
- enable Spark
  - Spark 3.2.3 - CDP 7.1.7.2050
- Set Schedule at `Dependent` and than choose  `Model Running`
- Set Resource Profile
  - At least 2CPU / 4MEM
- Click `Create` to create the Job

### 5. Save Result Job
- Navigate to CML Job
- Click `New Job`
- Give it the Name `Save Result` and Description
- Select Script `4_model_result_saving.py`
- Pick Runtime
  - Workbench -- Python 3.9 -- Standard -- 2024.08
- enable Spark
  - Spark 3.2.3 - CDP 7.1.7.2050
- Set Schedule at `Dependent` and than choose  `Model Postprocessing`
- Set Resource Profile
  - At least 2CPU / 4MEM
- Click `Create` to create the Job

### 6. Clean Data Job
- Navigate to CML Job
- Click `New Job`
- Give it the Name `Clean Data` and Description
- Select Script `5_clean_data.py`
- Pick Runtime
  - Workbench -- Python 3.9 -- Standard -- 2024.08
- enable Spark
  - Spark 3.2.3 - CDP 7.1.7.2050
- Set Schedule at `Dependent` and than choose  `Save Result`
- Set Resource Profile
  - At least 2CPU / 4MEM
- Click `Create` to create the Job





