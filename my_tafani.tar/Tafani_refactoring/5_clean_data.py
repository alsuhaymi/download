import logging
import os
import sys
import time
from pathlib import Path

from settings import settings
from utils import send_mail
from utils.logging_setup import setup_logger


def run():
    start = time.monotonic()
    try:
        data_path = Path(settings.data_path)
        logging.info(f"Cleaning data path {data_path}")
        print(data_path)
        for folder, subfolders, files in os.walk(data_path):
            for file in files:
                if file.endswith(".csv"):
                    path = os.path.join(folder, file)
                    logging.info(f"Removing file {path}")
                    os.remove(path)
        end = time.monotonic()
        logging.info(
            f"Cleaning ended successfully in {end-start:.2f} seconds"
        )
        return True, "Everything is ok !!"
    except Exception as err:
        logging.error(f" Failed to clean data path {data_path} due to error : {err}")
        end = time.monotonic()
        logging.info(f"Model result saving failed in {end-start:.2f} seconds")
        sys.exit(1)


if __name__ == "__main__":
    # setup logger
    log_file_path, log_file_database_path = setup_logger(
        "INFO", settings.log_dir, settings.log_file_name
    )
    status, message = run()
    # Mail Notification
    if settings.send_mail:
        send_mail(
            smtp_host=settings.smtp_host,
            smtp_port=settings.smtp_port,
            smtp_from=settings.smtp_from,
            smtp_to=settings.smtp_to,
            smtp_cc=settings.smtp_cc,
            content=message + "\nLog in attached file",
            subject=f"""Tafani - logs for Clean data job""",
            attachment=log_file_path,
        )
